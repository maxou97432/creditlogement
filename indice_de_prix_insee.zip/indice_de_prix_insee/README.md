# MLOps System - Price Index Models & Property Valuation

Système MLOps production-ready pour la modélisation d'indices de prix immobiliers et l'estimation de valeur foncière.

##  Fonctionnalités

### Étape 1 : Correction Holt-Winters
- Correction dynamique des biais CL vs INSEE
- Lissage exponentiel avec tendance amortie
- Sauvegarde/chargement des modèles

### Étape 2 : Calcul des Taux d'Inflation
- Taux par maille géographique (IRIS, Ville, Département)
- Gestion des effectifs minimums
- Table de taux par période

### Étape 3 : Estimation de Valeur Foncière
- Estimation basée sur taux d'inflation
- Fallback géographique (IRIS → Ville → Département)
- Mode batch pour estimations massives

## Structure

```
indice_prix_mlops/
├── config/
│   └── config.yaml              # Configuration centralisée
├── data/
│   ├── data_loader.py          # Chargement CL + INSEE
│   └── data_processor.py       # Preprocessing et fusion
├── models/
│   ├── holt_winters_model.py   # Modèle Holt-Winters
│   └── inflation_rate_calculator.py  # Calcul taux inflation
├── inference/
│   ├── apply_corrections.py    # Application corrections HW
│   └── estimate_property_value.py    # Estimation valeur foncière
├── artifacts/
│   ├── models/                 # Modèles HW sauvegardés
│   ├── corrected_prices/       # Prix corrigés
│   └── inflation_rates/        # Tables de taux
└── main.py                     # Point d'entrée CLI
```

##  Workflow Complet

### Étape 1 : Entraînement Holt-Winters

Entraîne les modèles de correction de biais pour chaque zone/type de bien.

```bash
python main.py --mode train_holt_winters
```

**Output** : Modèles sauvegardés dans `artifacts/models/latest/`

### Étape 2a : Application des Corrections

Applique les corrections HW aux prix bruts pour produire des prix corrigés.

```bash
python main.py --mode apply_corrections \
    --input_dir Z:/uflumth/gits/univers_elementaire/TI/resultats \
    --models_dir artifacts/models/latest \
    --output artifacts/corrected_prices/prix_corriges.csv
```

**Output** : Fichier CSV avec prix corrigés

### Étape 2b : Calcul des Taux d'Inflation

Calcule les taux d'inflation par maille géographique à partir des prix corrigés.

```bash
python main.py --mode calculate_rates \
    --input artifacts/corrected_prices/prix_corriges.csv \
    --output artifacts/inflation_rates/taux_inflation.csv
```

**Output** : Table de taux d'inflation par maille et période

### Étape 3a : Estimation Unitaire

Estime la valeur actuelle d'un bien immobilier.

```bash
python main.py --mode estimate \
    --rates artifacts/inflation_rates/taux_inflation.csv \
    --valeur_initiale 300000 \
    --date_achat 2022-03-15 \
    --type_bien APT \
    --code_iris 75101 \
    --ville PARIS \
    --dept 75
```

**Output** :
```
================================================================================
ESTIMATION DE VALEUR FONCIÈRE
================================================================================

 Période:
   Date d'achat      : 2022
   Année de référence: 2025
   Écart             : 3 ans

 Valeurs:
   Valeur initiale : 300,000.00 €
   Valeur estimée  : 321,600.00 €
   Variation       : +21,600.00 €

 Taux d'inflation:
   Taux appliqué   : +7.20%
   Niveau géo      : IRIS (75101)
   Effectif        : 145 transactions

 Taux trouvé au niveau IRIS
```

### Étape 3b : Estimation Batch

Estime la valeur pour un lot de biens depuis un fichier CSV.

**Format du fichier d'entrée** (`biens.csv`) :
```csv
valeur_initiale,date_achat,type_bien,code_iris,ville,dept
300000,2022-03-15,APT,75101,PARIS,75
250000,2023-06-20,APT,,PARIS,75
180000,2021-11-10,MAI,,,92
```

```bash
python main.py --mode estimate_batch \
    --rates artifacts/inflation_rates/taux_inflation.csv \
    --input biens.csv \
    --output estimations.csv
```

**Output** : Fichier CSV avec colonnes d'estimation ajoutées

##  Configuration

Modifiez `config/config.yaml` pour :

### Chemins des Données
```yaml
data:
  base_path: "Z:\\uflumth\\gits\\univers_elementaire\\TI\\resultats"
  insee_path: "Z:\\uflumth\\gits\\univers_elementaire\\TI\\table_rapport (2025)"
```

### Hyperparamètres Holt-Winters
```yaml
model:
  holt_winters:
    trend: 'add'
    damped_trend: true
    min_observations: 8
    n_forecast: 2
```

### Effectifs Minimums
```yaml
# Dans inflation_rate_calculator.py
min_effectifs = {
    'IRIS': 10,
    'CITY': 30,
    'DEPT': 50}
```

##  Méthodologie

### Fréquence Temporelle

**Données sources** :
- CL : Mensuelles
- INSEE : **Trimestrielles**

**Traitement** : Fusion au niveau **trimestriel**
- Les données CL mensuelles sont agrégées par trimestre
- Cohérence avec la fréquence INSEE
- Corrections HW appliquées sur données trimestrielles

### Calcul des Taux d'Inflation

1. **Période de référence** : Année la plus récente dans les données
2. **Périodes** : Distance en années depuis la référence (0, 1, 2, ...)
3. **Formule** : `taux = (prix_periode_0 - prix_periode_t) / prix_periode_t`
4. **Effectif** : `min(effectif_periode_0, effectif_periode_t)`
5. **Filtrage** : Effectif >= seuil minimum par niveau géographique

### Hiérarchie de Fallback

Lors de l'estimation, recherche du taux dans l'ordre :

1. **IRIS** (code à 5 chiffres) : Si effectif >= 10
2. **Ville** (nom) : Si effectif >= 30
3. **Département** (code à 2 chiffres) : Si effectif >= 50

### Propagation des Corrections HW

Les corrections sont propagées hiérarchiquement :
- **IRIS** → Cherche modèle IRIS, sinon hérite de la Ville
- **Ville** → Cherche modèle Ville, sinon hérite du Département
- **Département** → Cherche modèle Département, sinon hérite de la Région

**Exemple** : IRIS 75101 sans modèle → Utilise correction de PARIS

### Estimation de Valeur

```
valeur_estimee = valeur_initiale × (1 + taux_inflation)
```

##  Installation

```bash
# Cloner le projet
cd /Users/maximethiong-ly/Downloads/py/indice_prix_mlops

# Installer les dépendances
pip install -r requirements.txt
```

##  Dépendances

- pandas >= 1.5.0
- numpy >= 1.23.0
- pyyaml >= 6.0
- statsmodels >= 0.14.0
- scipy >= 1.10.0

## � Debugging

### Vérifier les modèles entraînés
```bash
ls artifacts/models/latest/
```

### Vérifier les prix corrigés
```bash
head artifacts/corrected_prices/prix_corriges.csv
```

### Vérifier la table de taux
```bash
head artifacts/inflation_rates/taux_inflation.csv
```
