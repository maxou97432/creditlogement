"""Holt-Winters Module
Modèle de lissage exponentiel pour correction de biais
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict
import sys
import yaml
import pickle
import json
from typing import Tuple, Dict, Optional
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import warnings

warnings.filterwarnings("ignore")

class HoltWintersModel:


    def __init__(self, zone :str, type_bien: str, config_path : str = None):

        self.zone = zone
        self.type_bien = type_bien
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config" / "config.yaml"

        with open(config_path, 'r',encoding = 'utf-8') as f:
            self.config = yaml.safe_load(f)


        hw_config = self.config['model']['holt_winters']
        self.trend = hw_config['trend']
        self.seasonal = hw_config['seasonal']
        self.damped_trend = hw_config['damped_trend']
        self.initialization_method = hw_config['initialization_method']
        self.min_observations = hw_config['min_observations']
        self.n_forecast = hw_config['n_forecast']
        self.confidence_level = hw_config['confidence_level']
        self.optimize_hyperparameters = hw_config.get('optimize_hyperparameters', False)
        self.cv_splits = hw_config.get('cv_splits', 3)

        # Modèle statsmodels
        self.model = None
        self.model_fit = None

        self.metadata = {
            'zone' : zone,
            'type_bien': type_bien,
            'trained': False,
            'n_observations': 0,
            'train_date': None,
            'metrics':{}
        }

    def optimize_hyperparameters(self, biais_series: pd.Series, n_splits: int = 3) -> Dict:
        """Optimisation des hyperparamètres par cross-validation temporelle

        Args:
            biais_series (pd.Series): _description_
            n_splits (int, optional): _description_. Defaults to 3.

        Returns:
            Dict: _description_
        """

        best_score = float('inf')
        best_params = None

        # Grid de paramètres
        param_grid = {
            'trend':['add', None],
            'damped_trend': [True, False],
        }

        results = []

        for trend in param_grid['trend']:
            for damped in param_grid['damped_trend']:
                if damped and trend is None:
                    continue
                try:
                    # Times Series Cross-validation
                    scores = []
                    n = len(biais_series)

                    for i in range(n_splits):
                        train_size = int(n * (i+1) / (n_splits + 1))
                        test_size = min(2, n - train_size)

                        if test_size == 0:
                            continue

                        train = biais_series.iloc[:train_size]
                        test = biais_series.iloc[train_size: train_size + test_size]

                        # Vérifier minimum observations
                        if len(train) < self.min_observations:
                            continue

                        # Entrainer
                        model = ExponentialSmoothing(
                            train,
                            trend = trend,
                            seasonal = self.seaonal,
                            damped_trend = damped,
                            initialization_method =self.initialization_method
                        )

                        fit = model.fit()
                    
                        # Prévisions
                        forecast = fit.forecast(len(test))

                        # RMSE sur validation
                        rmse = np.sqrt(np.mean((test.values - forecast)**2))
                        scores.append(rmse)
                
                    if len(scores) == 0:
                        continue

                    # Score moyen
                    avg_score = np.mean(scores)

                    results.append({
                        'trend' : trend,
                        'damped_trend': damped,
                        'cv_rmse': avg_score
                    })

                    if avg_score < best_score:
                        best_score = avg_score
                        best_params = {
                            'trend': trend,
                            'damped': damped
                        }
                
                except Exception as e:
                    continue

        if best_params is None:
            print(f"Optimisation échouée, utilisation des paramètres par défaut")
            best_params = {
                'trend': self.trend,
                'damped_trend': self.damped_trend
            }
            best_score = None
        else:
            print(f"Meilleurs paramètres: trend={best_params['trend']}, damped={best_params['damped_trend']}, CV-RMSE={best_score:.3f}")
        
        return {
            'best_params': best_params,
            "best_score": best_score,
            'all_results': results
        }

                
    def fit(self, biais_series: pd.Series, optimize: bool = True)-> bool:
        """Entriane le modèle sur la série de biais

        Args:
            bias_series (pd.Series): 
            optimize (bool):
        Returns:
            bool: True si entrainement reussi
        """
        
        if len(biais_series) < self.min_observations:
            print("Pas assez de données")
            return False

        
        try:
            # Optimisation des hyperparamètres
            if optimize and len(biais_series) >= 12:
                opt_result = self.optimize_hyperparameters(biais_series)

                # Utiliser les meilleurs hyperparamètres
                trend = opt_result['best_params']['trend']
                damped_trend = opt_result['best_params']['damped_trend']

                # Stocker résultats optimisation
                self.metadata['optimization'] = {
                    'optimized': True,
                    'cv_score': opt_result['best_params'],
                    'all_results': opt_result['all_results']
                }
            
            else:
                # utilisation des paramètres par défaut

                trend = self.trend
                damped_trend = self.damped_trend
                self.metadata['optimization'] = {'optimized': False}

            # Création du modèle
            self.model = ExponentialSmoothing(
                biais_series,
                trend = trend,
                seasonal = self.seasonal,
                seasonal_periods = None,
                damped_trend = damped_trend,
                initialization_method = self.initialization_method
            )
            # Entraînement
            self.model_fit = self.model.fit()

            # Mise à jour métadonnées
            self.metadata['trained'] = True
            self.metadata['n_observations'] = len(biais_series)
            self.metadata['train_date'] = pd.Timestamp.now().isoformat()
            self.metadata['final_params'] = {
                'trend': trend,
                'damped_trend': damped_trend
            }
            
            # Calcul métriques
            residuals = self.model_fit.resid
            self.metadata['metrics'] = {
                'rmse':float(np.sqrt(np.mean(residuals**2))),
                'mea': float(np.mean(np.abs(residuals))),
                'std_resid': float(np.std(residuals))
            }

            return True
    
        except Exception as e:
            print(f"Echec entrainement - {e}")
            return False
        

    def predict(self, last_cl_value: float):
        """Prédit les ajustements futurs et les indices corrigés

        Args:
            last_cl_value (float): Dernière valeur de l'indice CL
        """

        if not self.metadata['trained']:
            raise ValueError("Modèle non entraîné")
        
        #Prédiction du biais futur
        forecast_biais = self.model_fit.forecast(self.n_forecast)

        # Intervalle de confiance
        sigma = np.std(self.model_fit.resid)
        from scipy import stats
        z_score = stats.norm.ppf((1 + self.confidence_level) / 2)

        confidence_interval = [z_score * sigma * np.sqrt(step) for step in range(1,self.n_forecast + 1)]

        # Predictions : CL - biais

        predictions = last_cl_value -forecast_biais
        upper_bound = predictions + confidence_interval
        lower_bound = predictions - confidence_interval

        # Métadonnées
        pred_metadata = {
            'adjustements': [round(float(biais)) for biais in forecast_biais],
            'predictions': [round(float(pred)) for pred in predictions],
            'confidence_intervals': [
                (round(float(lower_bound[i]),2), round(float(upper_bound[i]),2))
                for i in range(self.n_forecast)
            ],
            'last_cl_value': round(last_cl_value, 2),
            'sigma': round(sigma, 4)
        }

    def backtest(self, full_series: pd.Series) -> pd.Series:
       """
       Calcule les valeurs corrigés historiques
       """
       if not self.metadata['trained']:
           raise ValueError("Modèle non entrainé")
       
       return self.model_fit.fittedvalues
    

    def save(self, filepath : str):
        """Sauvegarde le modèle

        Args:
            filepath (str): 
        """

        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True,exist_ok = True)

        # Sauvegarde modèle (pickle)

        model_path = filepath.with_suffix('.pkl')
        with open(model_path,'wb') as f:
            pickle.dump({
                'model':self.model,
                'model_fit':self.model_fit,
                'zone': self.zone,
                'type_bien': self.type_bien
            }, f)

        meta_path = filepath.with_suffix('.json')
        with open(meta_path, 'w',encoding = 'utf-8') as f:
            json.dump(self.metadata, f , indent = 2, ensure_ascii = False)

        print("Modèle sauvegardé")

    @classmethod
    def load(cls, filepath : str, config_path : str = None):
        """Charge un modèle sauvegardé

        Args:
            filepath (str): _description_
            config_path (str, optional): _description_. Defaults to None.
        """
        
        filepath = Path(filepath)

        # Chargement modèle
        model_path = filepath.with_suffix('.pkl')
        with open(model_path, 'rb') as f:
            data = pickle.load(f)

        # Chargement métadonnées
        meta_path = filepath.with_suffix('.json')
        with open(meta_path, encoding = 'utf-8') as f:
            metadata = json.load(f)


        instance = cls(data['zone'], data['type_bien'], config_path)
        instance.model = data['model']
        instance.model_fit = data['model_fit']
        instance.metadata = metadata

        return instance
    
    def get_metrics(self) -> Dict:
        """Retourne la métrique du modèle"""
        return self.metadata['metrics']
    
    def __repr__(self):
        status = 'Trained' if self.metadata['trained'] else "Not trained"
        return f"HoltWintersModel({self.zone}-{self.type_bien},{status})"
    




if __name__ == "__main__":
    # Exemple de série de biais
    dates = pd.date_range("2015-01-01", periods=60, freq="M")
    biais = pd.Series(np.random.randn(60), index=dates)

    # Création du modèle
    model = HoltWintersModel(zone="Paris", type_bien="APT")

    # Entraînement
    ok = model.fit(biais)

    if ok:
        print("Modèle entraîné")
        print(model.get_metrics())