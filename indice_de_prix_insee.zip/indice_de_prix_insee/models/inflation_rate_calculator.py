"""Inflation Rate Calculator Module
Calcule les taux d'inflation par maille géographique et période
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, Optional
import yaml


class InflationRateCalculator:
    """Calcule les taux d'inflation à partir des prix corrigés

    Méthodologie:
    1. Période 0 = année de référence
    2. Périodes 1, 2, 3... = années précédentes
    3. Taux = (prix_period_0 - prix_period_t) / prix_period_t
    4. Effectif = min(effectif_period_0, effectif_period_t)
    """

    def __init__(self, config_path: str = None):
        if config_path == None:
            config_path = Path(__file__).parent.parent / "config" / "config.yaml"

        with open(config_path, 'r', encoding ='utf-8') as f:
            self.config = yaml.safe_load(f)

        # Effectifs minimums par niveau géographique
        self.min_effectifs = {
            'IRIS': 10,
            'CITY': 30,
            'DEPT': 50
        }

        self.max_periods = 10


    def prepare_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prépare les donées pour le calcul des taux

        Args:
            df (pd.DataFrame): _description_

        Returns:
            pd.DataFrame: _description_
        """

        df = df.copy()
        df["Periode"] = pd.to_datetime(df['Periode'])
        df["annee"] = df['Periode'].dt.year

        def identity_geo_level(code):
            code_str = str(code).strip()
            if code_str.isdigit():
                if len(code_str) == 9:
                    return 'IRIS'
                if len(code_str) == 5:
                    return 'IRIS'
                if len(code_str) ==2:
                    return 'DEPT'
            
            return 'CITY'
        
        df['niveau_geo'] = df['VAL_MAILLE_GEO'].apply(identity_geo_level)

        return df
    

    def calculate_rates_for_level(self, df: pd.DataFrame, geo_level: str,
                                  geo_col: str = 'VAL_MAILLE_GEO',
                                  type_col: str = 'CD_TYPE_BIEN',
                                  price_col: str = 'prix_corrected') -> pd.DataFrame:
        """Calcule les taux d'inflations pour un niveau géographique donné.

        Args:
            df (pd.DataFrame): _description_
            geo_level (str): _description_
            geo_col (str, optional): _description_. Defaults to 'VAL_MAILLE_GEO'.
            type_col (str, optional): _description_. Defaults to 'CD_TYPE_BIEN'.
            price_col (str, optional): _description_. Defaults to 'prix_corrected'.

        Returns:
            pd.DataFrame: _description_
        """

        df_level = df[df['niveau_geo'] == geo_level].copy()
        
        if len(df_level) == 0:
            print(f"Aucune données au niveau {geo_level}")
            return pd.DataFrame()
        
        annee_ref = df_level['annee'].max()

        # Aggrégation par maille, type et année
        agg = df_level.groupby([geo_col,type_col,'annee']).agg({
            price_col: 'mean',
            'Periode': 'count'
        }).rename(columns={price_col: "prix_moyen", 'Periode': 'effectif'}).reset_index()

        # Prix et effectif e la période 0 (année de référence)
        periode_0 = agg[agg['annee'] == annee_ref].copy()
        periode_0 = periode_0.rename(columns={
            'prix_moyen': 'prix_moyen_0',
            'effectif': 'effectif_0'
        })

        # Fusion avec toutes les périodes
        rates = agg.merge(
            periode_0[[geo_col,type_col, 'prix_periode_0','effectif_0']], on = [geo_col, type_col], how = 'left'
        )

        rates['periode'] = annee_ref - rates['annee']

        # Calcul du taux d'inflation
        rates['taux_inflation'] = (rates['prix_periode_0'] - rates['prix_moyen']) / rates['prix_moyen']

        # Effectif 
        rates['effectif_final'] = rates[['effectif','effectif_0']].min(axis= 1)

        # Filtrage par effectif minimum

        min_eff = self.min_effectifs[geo_level]
        rates = rates[rates['effectif_final'] >= min_eff].copy()

        # Sélection des colonnes finales
        rates = rates[[
            geo_col, type_col, 'annee', 'periode', 'taux_inflation', 'effectif_final', 'niveau_geo'
        ]].rename(columns={'effectif_final': 'effectif'})

        return rates
    

    def calculate_all_rates(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calcule les taux pour tous les niveaux géographiques"""

        print("============================================")
        print("CALCUL DES TAUX D'INFLATIONS PAR MAILLE")
        print("============================================")

        df_prep = self.prepare_data(df)

        all_rates = []

        # Calcul par niveau

        for geo_level in ['IRIS','CITY','DEPT']:
            rates = self.calculate_rates_for_level(df_prep, geo_level)

            if len(rates) > 0:
                all_rates.append(rates)
        
        if not all_rates:
            raise ValueError("Aucun taux d'inflation calculé")
        
        # Consolidatioon
        df_rates = pd.concat(all_rates, ignore_index=True)

        # Tri
        df_rates = df_rates.sort_values(['niveau_geo','VAL_MAILLE_GEO','CD_TYPE_BIEN','periode'])

        return df_rates
    
    def save_rates_table(self, df_rates: pd.DataFrame, filepath: str):
        """Sauvegarde la table de taux d'inflation.

        Args:
            df_rates (pd.DataFrame): _description_
            filepath (str): _description_
        """

        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok = True)

        df_rates.to_csv(filepath, index = False, encoding = 'utf-8-sig')

        print("Table de taux sauvegardé")


if __name__ == "__main__":
    # Test avec données fictives
    print("Test InflationRateCalculator\n")
    
    # Données de test
    dates = pd.date_range('2020-01-01', periods=24, freq='Q')
    
    data = []
    for date in dates:
        # IRIS
        data.append({
            'Periode': date,
            'VAL_MAILLE_GEO': '75101',
            'CD_TYPE_BIEN': 'APT',
            'prix_corrected': 5000 + np.random.normal(0, 100) + (date.year - 2020) * 100
        })
        # Ville
        data.append({
            'Periode': date,
            'VAL_MAILLE_GEO': 'PARIS',
            'CD_TYPE_BIEN': 'APT',
            'prix_corrected': 5200 + np.random.normal(0, 100) + (date.year - 2020) * 120
        })
        # Dept
        data.append({
            'Periode': date,
            'VAL_MAILLE_GEO': '75',
            'CD_TYPE_BIEN': 'APT',
            'prix_corrected': 5100 + np.random.normal(0, 100) + (date.year - 2020) * 110
        })
    
    df = pd.DataFrame(data)
    
    # Calcul
    calculator = InflationRateCalculator()
    df_rates = calculator.calculate_all_rates(df)
    
    print("\nAperçu des taux:")
    print(df_rates.head(10))
    
    # Sauvegarde
    calculator.save_rates_table(df_rates, '/tmp/test_taux_inflation.csv')