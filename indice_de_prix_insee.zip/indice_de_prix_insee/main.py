import argparse
import sys
from pathlib import Path

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from data.data_loader import DataLoader
from data.data_preprocessor import DataPreprocessor
from models.holt_winters_model import HoltWintersModel
from models.inflation_rate_calculator import InflationRateCalculator
from inference.estimation import PropertyValueEstimator
import pandas as pd

def train_holt_winters(config_path : str = None):
    """Entraine les modèles Holt-Winters pour la correction du bias

    Args:
        config_path (str, optional): _description_. Defaults to None.
    """

    print("============================================")
    print("1. ENTRAINEMENT HOLT-WINTERS")
    print("============================================")

    # 1. Chargement des données

    loader = DataLoader()
    data_cl = loader.load_data()
    data_insee = loader.load_data_insee()

    # 2. Preprocessing
    processor = DataPreprocessor()
    df_merged = processor.process_all(data_cl,data_insee)

    # 3. Entrainement par zone / type
    print("============================================")
    print("ENTRAINEMENT DES MDOELES")
    print("============================================")

    models_dir = project_root / "artificats" / "models" / "latest"
    models_dir.mkdir(parents=True, exist_ok = True)

    trained_models = []

    grouped = df_merged.groupby(["VAL_MAILLE_GEO","CD_TYPE_BIEN"])

    for (zone, type_bien), group in grouped:
        print(f"{zone}-{type_bien}")

        # Serie de biais
        group = group.sort_values("Periode").set_index("Periode")
        bias_series = group['Dif'].dropna()

        # Création et entraînement
        model = HoltWintersModel(zone, type_bien, config_path)
        success = model.fit(bias_series)

        if success:
            # Sauvegarde

            model_path = models_dir / f"{zone}_{type_bien}"
            model.save(str(model_path))
            trained_models.append(model)

            metrics = model.get_metrics()
            print(f"RMSE: : {metrics['rmse']:.2f}, MAE: : {metrics['mae']:.2f}")

        print(f"{len(trained_models)} modèles entrainés")


def calculate_inflation_inflation_rates(input_path: str, output_path: str, config_path: str = None):
    """Calcule les taux d'inflation à partir des taux corrigés

    Args:
        input_path (str): _description_
        outputh_path (str): _description_
        config_path (str, optional): _description_. Defaults to None.
    """
    print("============================================")
    print("2. CALCUL DES TAUX D'INFLATIONS")
    print("============================================")

    df_corrected = pd.read_csv(input_path)
    df_corrected['Periode'] = pd.to_datetime(df_corrected['Periode'])

    # Calcul des taux

    calculator = InflationRateCalculator(config_path)
    df_rates = calculator.calculate_all_rates(df_corrected)
    calculator.save_rates_table(df_rates, output_path)


def estimate_property_value(rates_table: str,
                            valeur_initiale: float,
                            date_achat: str,
                            type_bien: str,
                            code_iris: str = None,
                            ville: str = None,
                            dept: str = None):
    """Estime la valeur d'un bien immobilier.

    Args:
        rates_table (str): _description_
        valeur_initiale (float): _description_
        date_achat (str): _description_
        type_bien (str): _description_
        code_iris (str, optional): _description_. Defaults to None.
        ville (str, optional): _description_. Defaults to None.
        dept (str, optional): _description_. Defaults to None.
    """

    print("============================================")
    print("3. ESTIMATION DE VALEUR FONCIERE")
    print("============================================")
    
    estimator = PropertyValueEstimator(rates_table)

    result = estimator.estimate(valeur_initiale=valeur_initiale,
                                date_achat = date_achat,
                                type_bien = type_bien,
                                code_iris = code_iris,
                                ville = ville,
                                dept = dept)
    
    estimator.print_estimation(result)


def estimate_batch(rates_table: str, input_csv: str, output_csv: str):
    """Estimation du'un lot de biens à partir d'un fichier csv.

    Args:
        rates_table (str): _description_
        input_csv (str): _description_
        output_csv (str): _description_
    """

    print("============================================")
    print("ESTIMATION DE VALEUR FONCIERE D'UN LOT DE BIENS")
    print("============================================")

    estimator = PropertyValueEstimator(rates_table)

    # Chargement
    df_biens = pd.read_csv(input_csv)

    # Estimation
    df_results = estimator.estimate_batch(df_biens)
    df_results.to_csv(output_csv, index = False, encoding = 'utf-8-sig')
    print("Résultats sauvegardés")



def apply_correction(config_path: str = None, models_dir: str = None, output_file : str = None):
    """Applique les corrections Holt-Winter aux indices de CL"""

    from inference.apply_correction import apply_corrections_pipeline

    apply_corrections_pipeline(config_path,models_dir,output_file )


def main():
    parser = argparse.ArgumentParser(
        description = "MLOps Pipeline - Prévision de valeur foncière par méthode de taux d'inflation corrigé par Holt-Winters",
        formatter_class= argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemple d'utilisation:

    # 1. Entraîner les modèles Holt-Winters
    python main.py --mode train_holt_winters

    #2.a Appliquer les corrections (charge automatiquement les données)
    python main.py --mode apply_corrections \\
    --models_dir artificats/models/latest \\
    --output artificats/corrected_prices/prix_corriges.csv

    #2.b Calculer les taux d'inflation
    python main.py --mode calculate_rates\\
    --input artificats/corrected_prices/prix_corriges.csv \\
    --output artificats/inflation_rates/taux.csv

    #3. Estimer une valeur
    python main.py --mode estimate\\
    --rates artificats/inflation_rates/taux.csv \\
    --valeur_initiale 300000 \\
    --date_achat initiale 2022-03-15 \\
    --type_bien APT \\
    --code_iris 75101 \\
    --ville PARIS \\
    --dept 75 \\
    
    # Estimation lots de bien
    python main.py--mode estimate_batch \\
    --rates artificat/inflation_rates/taux.csv \\
    --input biens.csv \\
    --output estimation.csv
"""
    )

    parser.add_argument('--mode', type=str, required=True,
                       choices=['train_holt_winters', 'apply_corrections', 
                               'calculate_rates', 'estimate', 'estimate_batch'],
                       help='Mode d\'exécution')
    
    # Arguments communs
    parser.add_argument('--config', type=str, help='Chemin config.yaml')
    
    # Arguments pour apply_corrections
    parser.add_argument('--input_dir', type=str, help='Répertoire des prix bruts')
    parser.add_argument('--models_dir', type=str, help='Répertoire des modèles HW')
    
    # Arguments pour calculate_rates et estimate
    parser.add_argument('--input', type=str, help='Fichier d\'entrée')
    parser.add_argument('--output', type=str, help='Fichier de sortie')
    parser.add_argument('--rates', type=str, help='Table de taux d\'inflation')
    
    # Arguments pour estimate
    parser.add_argument('--valeur_initiale', type=float, help='Valeur initiale (€)')
    parser.add_argument('--date_achat', type=str, help='Date d\'achat (YYYY-MM-DD)')
    parser.add_argument('--type_bien', type=str, help='Type de bien (APT/MAI/ENSEMBLE)')
    parser.add_argument('--code_iris', type=str, help='Code IRIS')
    parser.add_argument('--ville', type=str, help='Ville')
    parser.add_argument('--dept', type=str, help='Département')
    
    args = parser.parse_args()
    
    try:
        if args.mode == 'train_holt_winters':
            train_holt_winters(args.config)
        
        elif args.mode == 'apply_corrections':
            if not args.output:
                print("--output requis")
                sys.exit(1)
            apply_corrections(args.config, args.models_dir, args.output)
        
        elif args.mode == 'calculate_rates':
            if not args.input or not args.output:
                print("--input et --output requis")
                sys.exit(1)
            calculate_inflation_rates(args.input, args.output, args.config)
        
        elif args.mode == 'estimate':
            if not args.rates or not args.valeur_initiale or not args.date_achat or not args.type_bien:
                print("--rates, --valeur_initiale, --date_achat et --type_bien requis")
                sys.exit(1)
            estimate_property_value(
                args.rates, args.valeur_initiale, args.date_achat, args.type_bien,
                args.code_iris, args.ville, args.dept
            )
        
        elif args.mode == 'estimate_batch':
            if not args.rates or not args.input or not args.output:
                print("--rates, --input et --output requis")
                sys.exit(1)
            estimate_batch(args.rates, args.input, args.output)
    
    except Exception as e:
        print(f"\n Erreur: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
