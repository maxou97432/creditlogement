"""
Estimation Module
Estime la valeur foncière d'un bien immobilier en utilisant les taux d'inflation.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, Optional
from datetime import datetime


class PropertyValueEstimator:
    """Estime la valeur actualisée d'un bien immobilier à partir de :
    - Valeur foncière initiale
    - Date d'achat
    - Localisation (code IRIS -> Ville -> Département)
    """

    def __init__(self, rates_table_path: str):
        """
        Args:
            rates_table_path (str): Chemin vers la table des taux d'inflation CSV
        """
        self.rates_table = pd.read_csv(rates_table_path)
        self.annee_reference = self.rates_table["annee"].max()

    def _find_rate(
        self,
        periode: int,
        type_bien: str,
        code_iris: Optional[str] = None,
        ville: Optional[str] = None,
        dept: Optional[str] = None,
    ) -> Optional[Dict]:
        """Recherche le taux d'inflation en fonction de la zone géographique"""

        # Normalisation
        if type_bien:
            type_bien = type_bien.upper().strip()

        # 1. Recherche par IRIS
        if code_iris:
            code_iris = str(code_iris).strip()
            mask = (
                (self.rates_table["VAL_MAILLE_GEO"] == code_iris)
                & (self.rates_table["CD_TYPE_BIEN"] == type_bien)
                & (self.rates_table["periode"] == periode)
                & (self.rates_table["niveau_geo"] == "IRIS")
            )

            result = self.rates_table[mask]
            if len(result) > 0:
                row = result.iloc[0]
                return {
                    "taux_inflation": row["taux_inflation"],
                    "effectif": row["effectif"],
                    "niveau_geo": "IRIS",
                    "maille": code_iris,
                }

        # 2. Recherche par VILLE
        if ville:
            ville = ville.upper().strip()
            mask = (
                (self.rates_table["VAL_MAILLE_GEO"] == ville)
                & (self.rates_table["CD_TYPE_BIEN"] == type_bien)
                & (self.rates_table["periode"] == periode)
                & (self.rates_table["niveau_geo"] == "VILLE")
            )

            result = self.rates_table[mask]
            if len(result) > 0:
                row = result.iloc[0]
                return {
                    "taux_inflation": row["taux_inflation"],
                    "effectif": row["effectif"],
                    "niveau_geo": "VILLE",
                    "maille": ville,
                }

        # 3. Recherche par DEPT
        if dept:
            dept = str(dept).strip()
            mask = (
                (self.rates_table["VAL_MAILLE_GEO"] == dept)
                & (self.rates_table["CD_TYPE_BIEN"] == type_bien)
                & (self.rates_table["periode"] == periode)
                & (self.rates_table["niveau_geo"] == "DEPT")
            )

            result = self.rates_table[mask]
            if len(result) > 0:
                row = result.iloc[0]
                return {
                    "taux_inflation": row["taux_inflation"],
                    "effectif": row["effectif"],
                    "niveau_geo": "DEPT",
                    "maille": dept,
                }

        # Aucun taux trouvé
        return None

    def estimate(
        self,
        valeur_initiale: float,
        date_achat: str,
        type_bien: str,
        code_iris: Optional[str] = None,
        ville: Optional[str] = None,
        dept: Optional[str] = None,
    ) -> Dict:
        """Estime la valeur actuelle d'un bien immobilier"""

        date_achat_dt = pd.to_datetime(date_achat)
        annee_achat = date_achat_dt.year
        periode = self.annee_reference - annee_achat

        if periode < 0:
            return {
                "success": False,
                "message": "Date d'achat postérieure à l'année de référence",
            }

        if periode == 0:
            return {
                "success": True,
                "valeur_estimee": valeur_initiale,
                "taux_utilise": 0.0,
                "niveau_geo": "N/A",
                "effectif": 0,
                "periode": 0,
                "maille": "N/A",
                "message": "Même année que l'année de référence",
            }

        # Recherche du taux
        rate_info = self._find_rate(periode, type_bien, code_iris, ville, dept)

        if rate_info is None:
            return {
                "success": False,
                "message": f"Aucun taux trouvé pour période={periode}, type_bien={type_bien}, code_iris={code_iris}, ville={ville}, dept={dept}",
            }

        taux = rate_info["taux_inflation"]
        valeur_estimee = valeur_initiale * (1 + taux)

        return {
            "success": True,
            "valeur_estimee": valeur_estimee,
            "taux_utilise": round(taux, 6),
            "taux_pourcent": round(taux * 100, 2),
            "niveau_geo": rate_info["niveau_geo"],
            "maille": rate_info["maille"],
            "effectif": rate_info["effectif"],
            "periode": periode,
            "annee_achat": annee_achat,
            "annee_reference": self.annee_reference,
            "message": f"Taux trouvé au niveau {rate_info['niveau_geo']}",
        }

    def estimate_lot(self, df_biens: pd.DataFrame) -> pd.DataFrame:
        """Estime la valeur d'un lot complet de biens"""

        print(f"Estimation pour un lot de {len(df_biens)} biens")

        results = []

        for idx, row in df_biens.iterrows():
            result = self.estimate(
                valeur_initiale=row["valeur_initiale"],
                date_achat=row["date_achat"],
                type_bien=row["type_bien"],
                code_iris=row.get("code_iris"),
                ville=row.get("ville"),
                dept=row.get("dept"),
            )
            results.append(result)

        df_results = pd.DataFrame(results)

        df_output = pd.concat(
            [df_biens.reset_index(drop=True), df_results], axis=1
        )

        success_count = df_results["success"].sum()
        print(f"{round(success_count / len(df_biens), 2)} estimations réussies")

        if success_count > 0:
            avg_taux = df_results[df_results["success"]]["taux_pourcent"].mean()
            print(f"Taux moyen : {avg_taux:.2f}")

        return df_output
