    """
    Apply Correction Module
    Applique les corrections Holt-Winters aux indices bruts pour produire des indices corrigés
    """

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from models.holt_winters_model import HoltWintersModel
from data.data_loader import DataLoader
from data.data_preprocessor import DataPreprocessor
from data.geo_hierarchy import GeoHierarchy

def find_model_with_fallback(zone: str,
                             type_bien: str,
                             models_dir : Path,
                             geo_hierarchy: GeoHierarchy) -> tuple:
    
    """Cherche un modèle HW avec fallback hiérarchique.

    Args:
        zone (str): _description_
        type_bien (str): _description_
        models_dir (Path): _description_
        geo_hierarchy (GeoHierarchy): _description_

    Returns:
        tuple: _description_
    """

    hierarchy = geo_hierarchy.get_hierarchy(zone)

    for geo_level in hierarchy:
        model_path = models_dir / f"{geo_level}_{type_bien}"

        if model_path.with_suffix(".pkl").exists():
            try:
                model = HoltWintersModel.load(str(model_path))
                return model, geo_level
            except Exception as e:
                print(f'Erreur de chargement {geo_level}_{type_bien}: {e}')
                continue
    
    return None, None

def apply_holt_winters_corrections(df_merged : pd.DataFrame, 
                                   models_dir : str,
                                   base_year : int = 2020) -> pd.DataFrame:
    """
    Applique les corrections Holt-Winters aux indices CL pour produire des indices corrigés


    Méthodologie:
    1. Pour chaque zone/type on charge le modèle HW
    2. Calculer le biais prédit 
    3. Corriger l'inidice CL: indice_corrigé = indice_cl - biais_prédit

    """

    print("============================================")
    print("APPLICATION DES CORRECTIONS HOLT-WINTERS")
    print("============================================")

    models_dir = Path(models_dir)

    if not models_dir.exists():
        print("Répertoir modèles introuvables")
        df_merged["indices_corriges"] = df_merged["Indice de prix (CL)"]
        df_merged["correction"] = False
        df_merged['correction_source'] = None
        
        return df_merged
    
    geo_hierarchy = GeoHierarchy()
    geo_hierarchy.build_from_data(df_merged)

    print(f'{geo_hierarchy}')
    df_merged = df_merged.copy()
    df_merged['Periode'] = pd.to_datetime(df_merged['Periode'])
    df_merged = df_merged.sort_values(['VAL_MAILLE_GEO','CD_TYPE_BIEN','Periode'])


    df_merged['Indice de prix (CL) - Corrigé'] = df_merged['Indice de prix (CL)']
    df_merged['correction'] = False
    df_merged['correction_source'] = None

    grouped = df_merged.groupby(['VAL_MAILLE_GEO','CD_TYPE_BIEN'])

    corrections_count = 0
    corrections_direct = 0
    corrections_parent = 0
    total_groups = len(grouped)


    print("============================================")
    print("APPLICATION DES CORRECTIONS PAR ZONE/TYPE")
    print("============================================")


    for (zone,type_bien), group in grouped:
        model, source_level = find_model_with_fallback(zone, type_bien, models_dir, geo_hierarchy)

        if model is None:
            continue

        try:

            biais_series = group.set_index('Periode')['Dif'].dropna()

            if len(biais_series) == 0:
                continue
            
            # Backtest
            biais_fitted = model.backtest(biais_series)

            # Déterminer le type de correction

            if source_level == zone:
                correction_type = 'direct'
                corrections_direct += 1
            
            else: 
                correction_type = f"parent_{source_level}"
                corrections_parent += 1
                print(f"{zone}-{type_bien}: correction via {source_level}")

            # Application de la correction
            for idx in group.index:
                periode = group.loc[idx,'Periode']
                if periode in biais_fitted.index:
                    biais_predit = biais_fitted.loc[periode]
                    indice_cl = group.loc[idx, 'Indice de prix (CL)']

                    indice_corrige = indice_cl - biais_predit

                    df_merged.loc[idx, 'Indice de prix (CL) - Corrigé'] = indice_corrige
                    df_merged.loc[idx, 'correction'] = True
                    df_merged.loc[idx, 'correction_source'] = correction_type
            corrections_count += 1
        except Exception as e:
            print(f"Erreur pour {zone} - {type_bien} : {e}")


    print(f"\n Corrections appliquées à {corrections_count}/{total_groups} zones/types")
    print(f"   → Corrections directes: {corrections_direct}")
    print(f"   → Corrections via parent: {corrections_parent}")
    
    # Statistiques de couverture
    total_obs = len(df_merged)
    corrected_obs = df_merged['correction'].sum()
    coverage = corrected_obs / total_obs * 100 if total_obs > 0 else 0
    print(f"   → Couverture: {corrected_obs}/{total_obs} observations ({coverage:.1f}%)")
    

    
    return df_merged


def save_correction(df : pd.DataFrame, output_path : str):
    """Sauvegarde les corrections

    Args:
        df (pd.DataFrame): 
        output_path (str): 
    """

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    cols_to_save = ['VAL_MAILLE_GEO','CD_TYPE_BIEN','Periode','Indice de prix (CL)','Indice de prix (INSEE) - Base 2020','Indice de prix (CL) - Corrigé','correction','correction_source']
    cols_to_save = [col for col in cols_to_save if col in df.columns]

    df_output = df[cols_to_save].copy()

    df_output.to_csv(output_path, index = False, encoding='utf-8-sig')



def apply_corrections_pipeline(config_path: str = None,
                               models_dir : str = None,
                               output_path : str = None):
    
    print("============================================")
    print("PIPELINE")
    print("============================================")

    print("Chargement des données...")
    loader = DataLoader()
    processor = DataPreprocessor()
    df_cl = loader.load_data()
    df_insee = loader.load_data_insee()
    df_merged = processor.process_all(df_cl,df_insee)

    if models_dir is None:
        models_dir = Path(__file__).parent.parent / "artificats" / "models" / "latest"

    df_corrected = apply_holt_winters_corrections(df_merged, models_dir)

    if output_path is None:
        output_path = Path(__file__).parent.parent / "artificats" / "corrected_indexes" / "indices_corriges.csv"

    save_correction(df_corrected, output_path)

    return df_corrected
    

if __name__ == "__main__":

    import argparse
    parser = argparse.ArgumentParser(description="Application corrections Holt-Winters")
    parser.add_argument('--config', type=str, help="Chemin config.yaml")
    parser.add_argument('--models', type=str, help="Repertoir des modeles")
    parser.add_argument('--output', type=str, help="Fichiers de sortie")

    args = parser.parse_args()
    apply_corrections_pipeline(args.config, args.models, args.output)
