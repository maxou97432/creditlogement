    """ Hiérarchie géographique Module
    Gère la hiérarchie géographique pour la propagation des corrections
    """

import pandas as pd
from typing import Dict, List, Optional

class GeoHierarchy:
    """Gère la hiérarchie géographique pour propagation des corrections HW.
    Hierarchie: IRIS -> Ville -> Département -> Région -> National
    """

    def __init__(self):
        # Mapping géographique

        self.iris_to_city: Dict[str, str] = {}
        self.city_to_dept: Dict[str, str] = {}
        self.dept_to_region: Dict[str, str] = {}

        self.city_to_iris: Dict[str, str] = {}

    def build_from_data(self,df: pd.DataFrame) -> 'GeoHierarchy':
        """ Construit la hiérarchie depuis les données CL

        Args:
                df (pd.DataFrame): 

        Returns:
            GeoHierarchy: 
        """

        #1. IRIS -> Ville

        if 'code_iris' in df.columns and 'Ville' in df.columns:
            iris_city = df[['code_iris','Ville']].dropna()
            iris_city = iris_city[(iris_city['code_iris'].astype(str).str.len() == 5) & (iris_city['code_iris'].astype(str).str.isdigit())]
            iris_city = iris_city.drop_duplicates()

        for _, row in iris_city.iterrows():
            iris_full = str(row['code_iris']).strip()
            ville = str(row["ville"]).strip().upper()

            # Extraire code commune (5 premiers chiffres)
            # Format IRIS: 9 chiffres
            # Format commune : 5 chiffres
            iris_commune = iris_full[:5]

            self.iris_to_city[iris_commune] = ville

            # Mapping inverse
            if ville not in self.city_to_iris:
                self.city_to_iris[ville] = []
            if iris_commune not in self.city_to_iris[ville]:
                self.city_to_iris[ville].append(iris_commune)

        #2. Ville -> Département
        for iris, ville in self.iris_to_city.items():
            dept = iris[:2]
            if ville not in self.city_to_dept:
                self.city_to_dept[ville] = dept
            
        #3. Département -> Région
        self._build_dept_to_region()

        return self

    def _build_dept_to_region(self):
        """Mapping statique Département -> Région"""
        # Île-de-France
        idf_depts = ['75', '77', '78', '91', '92', '93', '94', '95']
        for dept in idf_depts:
            self.dept_to_region[dept] = 'ÎLE-DE-FRANCE'
        
        # Autres régions principales
        regions = {
            'PROVENCE-ALPES-CÔTE D\'AZUR': ['04', '05', '06', '13', '83', '84'],
            'AUVERGNE-RHÔNE-ALPES': ['01', '03', '07', '15', '26', '38', '42', '43', '63', '69', '73', '74'],
            'NOUVELLE-AQUITAINE': ['16', '17', '19', '23', '24', '33', '40', '47', '64', '79', '86', '87'],
            'OCCITANIE': ['09', '11', '12', '30', '31', '32', '34', '46', '48', '65', '66', '81', '82'],
            'HAUTS-DE-FRANCE': ['02', '59', '60', '62', '80'],
            'GRAND EST': ['08', '10', '51', '52', '54', '55', '57', '67', '68', '88'],
            'BRETAGNE': ['22', '29', '35', '56'],
            'PAYS DE LA LOIRE': ['44', '49', '53', '72', '85'],
            'NORMANDIE': ['14', '27', '50', '61', '76'],
            'BOURGOGNE-FRANCHE-COMTÉ': ['21', '25', '39', '58', '70', '71', '89', '90'],
            'CENTRE-VAL DE LOIRE': ['18', '28', '36', '37', '41', '45'],
        }

        for region, depts in regions.items():
            for dept in depts:
                self.dept_to_region[dept] = region

    def get_parent(self, geo_code: str) -> Optional[str]:
        """Retourne le parent géographique

        Args:
            geo_code (str): 

        Returns:
            Optional[str]: 
        """
        geo_code = str(geo_code).strip()

        # Code commune/IRIS
        if len(geo_code) == 5 and geo_code.isdigit():
            return self.iris_to_city.get(geo_code)
        
        # Ville -> Département 
        if len(geo_code) in self.city_to_dept[geo_code]:
            return self.city_to_dept[geo_code]

        # Département -> Région
        if len(geo_code) == 2 and geo_code.isdigit():
            return self.dept_to_region.get(geo_code)
        
        return None
    

    def get_hierarchy(self, geo_code: str) -> List[str]:
        """Retourne la hiérarchie complète du plus spécifique au plus général

        Args:
            geo_code (str): _description_

        Returns:
            List[str]: _description_
        """

        hierarchy = [geo_code]
        current = geo_code
        max_depth = 10
        depth = 0

        while depth < max_depth:
            parent = self.get_parent(current)
            if parent is None:
                break
        
        # Eviter les doublons
        if parent not in hierarchy:
            hierarchy.append(parent)

        current = parent
        depth += 1

        return hierarchy
    
    def get_level(self, geo_code: str)-> str:
        """Identifie le niveau géographique

        Args:
            geo_code (str): _description_

        Returns:
            str: _description_
        """
        geo_code = str(geo_code).strip()

        if len(geo_code) == 5 and geo_code.isdigit():
            return "COMMUNE"
        
        if len(geo_code) == 2 and geo_code.isdigit():
            return 'DEPT'
        
        if geo_code in self.city_to_dept:
            return 'CITY'
        
        if geo_code in self.dept_to_region:
            return 'REGION'
        
        return 'UNKNOWN'
    
   def get_stats(self) -> Dict:
        """Retourne des statistiques sur la hiérarchie."""
        return {
            'iris_count': len(self.iris_to_city),
            'city_count': len(self.city_to_dept),
            'dept_count': len(set(self.city_to_dept.values())),
            'region_count': len(set(self.dept_to_region.values()))
        }
    
    def __repr__(self):
        stats = self.get_stats()
        return (f"GeoHierarchy("
                f"IRIS={stats['iris_count']}, "
                f"Cities={stats['city_count']}, "
                f"Depts={stats['dept_count']}, "
                f"Regions={stats['region_count']})")


if __name__ == "__main__":
    # Test
    print("Test GeoHierarchy\n")
    
    # Données de test avec codes IRIS réels (9 chiffres)
    test_data = pd.DataFrame({
        'code_iris': ['751010101', '751020202', '130550201', '693810305'],
        'Ville': ['PARIS', 'PARIS', 'MARSEILLE', 'LYON'],
        'VAL_MAILLE_GEO': ['75101', '75102', '13201', '69381']
    })
    
    # Construction
    hierarchy = GeoHierarchy()
    hierarchy.build_from_data(test_data)
    
    print(f"\n{hierarchy}")
    
    # Tests
    print("\nTests de hiérarchie:")
    
    # Test avec codes commune (5 digits extraits)
    test_cases = ['75101', 'PARIS', '75', 'ÎLE-DE-FRANCE']
    for code in test_cases:
        level = hierarchy.get_level(code)
        parent = hierarchy.get_parent(code)
        full_hierarchy = hierarchy.get_hierarchy(code)
        
        print(f"\n{code} ({level}):")
        print(f"  Parent: {parent}")
        print(f"  Hiérarchie: {' → '.join(full_hierarchy)}")

