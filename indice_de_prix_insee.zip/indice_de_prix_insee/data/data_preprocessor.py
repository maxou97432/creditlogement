""""
Data Processor Module
Preprocessing, fusion, et calcul des indices de prix
"""

import pandas as pd
import numpy as np
import sys
import os
from pathlib import Path
import yaml


class DataPreprocessor:

    def __init__(self, config_path : str = None):

        if config_path is None:
            config_path = Path(__file__).parent.parent / "config" / "config.yaml"

        with open(config_path, 'r', encoding = 'utf-8') as f:
            self.config = yaml.safe_load(f)
        
        self.base_year = self.config['data']['base_year']
    
    def calculate_cl_index(self, df_cl: pd.DataFrame) -> pd.DataFrame:
        """
        Calcule l'indice CL base 2020.
        
        Args:
            df_cl: DataFrame CL brut
            
        Returns:
            DataFrame avec colonne 'Indice de prix (CL)'
        """
        print(f"\nCalcul indice CL (Base {self.base_year})...")

        # Court-circuit : indice déjà calculé par calc_indice.py de la pipeline indicateur_prix
        if "Indice de prix (CL)" in df_cl.columns and df_cl["Indice de prix (CL)"].notna().any():
            print(f"   ✓ Indice CL importé depuis calc_indice.py ({df_cl['VAL_MAILLE_GEO'].nunique()} zones)")
            return df_cl
    
    def calcul_insee_indice(self, df_insee: pd.DataFrame) -> pd.DataFrame:
        """Calcule des indices de prix de l'INSEE en base 2020

        Args:
            df_cl (pd.DataFrame): _description_

        Returns:
            pd.DataFrame: _description_
        """

        df_insee["Periode"] = pd.to_datetime(df_insee["Periode"])
        mask_2020_insee = df_insee["Periode"].dt.year == self.base_year

        if not df_insee.loc[mask_2020_insee].empty:
            pivot_2020_insee = df_insee.loc[mask_2020_insee].groupby(
                ["CD_TYPE_BIEN", "VAL_MAILLE_GEO"]
            )["Indice de prix (INSEE)"].mean()
    
            df_insee["Indice de prix (INSEE) - Base 2020"] = (
                (df_insee["Indice de prix (INSEE)"] / 
                df_insee.set_index(["CD_TYPE_BIEN", "VAL_MAILLE_GEO"]).index.map(pivot_2020_insee)
                ) * 100 
            ).round(2)
    
            print(" Indice INSEE rebasé sur 2020")
        else:
            print("  Attention: Données INSEE 2020 manquantes.")
            df_insee["Indice de prix (INSEE) - Base 2020"] = np.nan
         
        return df_insee
        
    
    def merge_data(self,df_cl: pd.DataFrame, df_insee: pd.DataFrame) -> pd.DataFrame:
        """Fusionne les données de l'INSEE et de CL

        Args:
            df_cl (pd.DataFrame): 
            df_insee (pd.DataFrame): 

        Returns:
            pd.DataFrame: 
        """

        for df in (df_cl, df_insee):
            df["VAL_MAILLE_GEO"] = df["VAL_MAILLE_GEO"].astype(str).str.strip().str.upper()
            df["CD_TYPE_BIEN"] = df["CD_TYPE_BIEN"].astype(str).str.strip().str.upper()

        # Création de la clé string ROBUSTE "YYYYQx" (Ex: "2025Q2")
        df_cl['Periode_Key'] = df_cl["Periode"].dt.to_period('Q').astype(str)
        df_insee['Periode_Key'] = df_insee["Periode"].dt.to_period('Q').astype(str)

        # DIAGNOSTIC: Vérification des doublons dans INSEE avant la fusion
        duplicates_check = df_insee.groupby(['VAL_MAILLE_GEO', 'CD_TYPE_BIEN', 'Periode_Key']).size()
        doublons = duplicates_check[duplicates_check > 1]

        if not doublons.empty:
            print(f"\n  ATTENTION: {len(doublons)} doublons détectés dans les données INSEE !")
            print(" Exemples de doublons:")
            print(doublons.head(10))
    
            # DÉDUPLICATION: Moyenne des valeurs en cas de doublon
            print("\n Déduplication en cours (moyenne des valeurs)...")
            df_insee = df_insee.groupby(
                ['VAL_MAILLE_GEO', 'CD_TYPE_BIEN', 'Periode_Key'], 
                as_index=False
            ).agg({
                'Periode': 'first',  # Garder la première valeur de Periode (elles sont identiques pour un même trimestre)
                'Indice de prix (INSEE)': 'mean',
                'Indice de prix (INSEE) - Base 2020': 'mean'
            })
            print(f" Après déduplication : {len(df_insee)} observations uniques")

        # --- Fusion (Merge) ---
        merge = pd.merge(
            df_cl, 
            df_insee.drop(columns=['Periode'], errors='ignore'), # On enlève la date Timestamp INSEE pour éviter doublon
            how="inner",
            left_on=["VAL_MAILLE_GEO", "CD_TYPE_BIEN", "Periode_Key"],
            right_on=["VAL_MAILLE_GEO", "CD_TYPE_BIEN", "Periode_Key"]
        )

        # --- Nettoyage Final et Conversion Date ---

        # Renommer la clé de fusion pour la clarté 
        merge = merge.rename(columns={'Periode_Key': 'Periode_Trimestre_Str'})
        merge = merge[merge['Periode_Trimestre_Str'].str.match(r'^\d{4}Q\d$', na=False)]

        # Reconstruction de l'index temporel propre
        merge["Periode"] = pd.PeriodIndex(merge['Periode_Trimestre_Str'], freq='Q').to_timestamp(how="end")
        temp_period = pd.PeriodIndex(merge['Periode_Trimestre_Str'],freq='Q').to_timestamp(how='end')
        merge["Periode"] = temp_period.normalize().map(lambda x: x.replace(day=1))

        merge = merge.drop(columns=['prix_mm_value', 'Periode_Trimestre_Str', 'Periode_Merge'], errors='ignore')
        merge = merge.loc[:, ~merge.columns.duplicated()]

        # Tri final
        merge = merge.sort_values(["VAL_MAILLE_GEO", "CD_TYPE_BIEN", "Periode"])

        print(f"\n Fusion réussie ! {len(merge)} lignes prêtes pour l'analyse.")
        merge = merge[~merge["Indice de prix (INSEE) - Base 2020"].isna()]

        # Affichage des premières lignes
        print("\n Aperçu des données fusionnées:")
        print(merge.head())

        return merge


    def process_all(self,df_cl: pd.DataFrame, df_insee: pd.DataFrame) -> pd.DataFrame:
        """Pipeline complet de preprocessing

        Args:
            df_cl (pd.DataFrame): 
            df_insee (pd.DataFrame): 

        Returns:
            pd.DataFrame: 
        """
        print("===========================================")
        print("PREPROCESSING DES DONNEES")
        print("===========================================")
        df_cl = self.caclul_cl_indice(df_cl)
        df_insee = self.calcul_insee_indice(df_insee)
        df_merged = self.merge_data(df_cl, df_insee)
        print("===========================================")
        print("PREPROCESSING TERMINE")
        print("===========================================")
        
        return df_merged
    
if __name__ == "__init__":
    from data_loader import DataLoader
    loader = DataLoader()
    processor = DataPreprocessor()

    df_cl = loader.load_cl_data()
    df_insee = loader.load_insee_data()

    df_final = processor.process_all(df_cl, df_insee)

    print("===========================================")
    print("APERCU DES DONNEES FINALES")
    print("===========================================")
    print(df_final.head())