"""
pipeline/base_restreinte.py — Wrapper d'appel à base_restreinte.py (py/).

Cette étape crée base_restreinte.parquet (CL uniquement).
Elle délègue au script existant dans py/ sans le dupliquer.
"""
import subprocess
import sys
import os


def run(cfg: dict):
    """Lance base_restreinte.py depuis py/ avec le bon environnement."""
    parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    script = os.path.join(parent_dir, "base_restreinte.py")

    if not os.path.exists(script):
        print(f"  ⚠ Script introuvable : {script}")
        return

    print(f"  → Lancement de {script}")
    result = subprocess.run([sys.executable, script], cwd=parent_dir)
    if result.returncode != 0:
        print(f"  ✗ base_restreinte.py a terminé avec une erreur (code {result.returncode})")
    else:
        print("  ✓ base_restreinte.py terminé avec succès")
