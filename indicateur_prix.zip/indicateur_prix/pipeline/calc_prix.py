"""
pipeline/calc_prix.py — Calcul des indices de prix au m² (toutes mailles × tous segments).

Amélioration de performances par rapport à calc_prix_m2_univ_elem.py :
- `build_univers_complet()` (agrégation mensuelle + complete_months) est exécuté
  UNE SEULE FOIS par maille, puis les 9 combinaisons TYPE_BIEN × ANCIENNETE
  sont calculées sur le cache, sans refaire l'étape lourde.

Paramètres reçus desde cfg (config.py) :
    path_base      : parquet sur lequel calculer les prix
    path_structure : parquet pour les poids structurels (peut être différent)
    source_filter  : filtre SOURCE ("CL" | None)
    label          : "V1" | "V2"
    output_dir     : dossier de sortie

Sorties :
    prix_m2_univ_elem_ALL.csv     — toutes périodes, toutes mailles, tous segments
    prix_m2_univ_elem_MAJ_ALL.csv — dernière période par zone × segment
    structure_poids_<MAILLE>.csv  — poids structurels
"""
import sys
import os
from datetime import datetime
import pandas as pd
import numpy as np

# Imports locaux (fonctions.py et param_generaux.py sont copiés dans indicateur_prix/)
import param_generaux as params
from fonctions import (
    load_and_preprocess_data,
    apply_nice_correction,
    get_structure_reference_city,
)

# ---------------------------------------------------------------------------
# Constantes
# ---------------------------------------------------------------------------
TYPES_BIEN   = ["APT", "MAI"]
ANCIENNETES  = ["NEUF", "ANCIEN"]
TYPOKEYS     = ["Ville", "BIEN_NEUF", "TYPE_BIEN", "NB_PIECES_RANGE"]


# ===========================================================================
# ÉTAPE LOURDE (1× par maille) : agrégation mensuelle + complete_months
# ===========================================================================

def build_univers_complet(df: pd.DataFrame) -> pd.DataFrame:
    """
    Construit l'univers mensuel complet (agrégation + complétion des mois).

    Cette fonction est la partie lente du pipeline — elle doit être appelée
    UNE SEULE FOIS par maille, puis filtrée pour chaque segment.

    Parameters
    ----------
    df : pd.DataFrame avec colonnes Ville, BIEN_NEUF, TYPE_BIEN,
         NB_PIECES_RANGE, Periode, ID, Prix_m2, NB_SURF_HAB, VALEUR_FONCIERE

    Returns
    -------
    pd.DataFrame : univers_complet avec tous les mois remplis
    """
    keys = ["Ville", "BIEN_NEUF", "TYPE_BIEN", "NB_PIECES_RANGE", "Periode"]
    univers_mensuel = (
        df.groupby(keys, dropna=False)
        .agg(
            nb_transac=("ID", "size"),
            prix_moyen=("Prix_m2", "mean"),
            surface_moyen=("NB_SURF_HAB", "mean"),
            valeur_fonc_moyen=("VALEUR_FONCIERE", "mean")
        )
        .reset_index()
    )

    # Cohérence TYPE_BIEN / NB_PIECES_RANGE
    univers_mensuel["PB"] = univers_mensuel["NB_PIECES_RANGE"].astype(str).str.strip().str[:3].str.upper()
    univers_mensuel["TYPE_BIEN"] = univers_mensuel["TYPE_BIEN"].astype(str).str.strip().str.upper()
    univers_mensuel = univers_mensuel[univers_mensuel["TYPE_BIEN"] == univers_mensuel["PB"]].drop(columns=["PB"])

    def complete_months(g):
        g = g.sort_values("Periode").set_index("Periode")
        idx = pd.date_range(g.index.min(), g.index.max(), freq="MS")
        g = g.reindex(idx)
        for col in ["Ville", "BIEN_NEUF", "TYPE_BIEN", "NB_PIECES_RANGE"]:
            g[col] = g[col].ffill().bfill()
        g["nb_transac"] = g["nb_transac"].fillna(0)
        return g.reset_index().rename(columns={"index": "Periode"})

    univers_complet = (
        univers_mensuel.groupby(TYPOKEYS, group_keys=False, include_groups=False)
        .apply(complete_months)
    )
    return univers_complet


# ===========================================================================
# ÉTAPES LÉGÈRES (9× par maille) : filtre + poids + calc_mm
# ===========================================================================

def _calc_mm_on_cache(
    univers_complet: pd.DataFrame,
    label: str,
    structure: pd.DataFrame,
    type_bien: str,
    anciennete: str
) -> pd.DataFrame | None:
    """
    Calcule les moyennes mobiles sur un sous-ensemble du cache univers_complet.

    Parameters
    ----------
    univers_complet : cache déjà construit par build_univers_complet()
    label           : label court ("V1" | "V2")
    structure       : DataFrame avec [Ville, BIEN_NEUF, TYPE_BIEN, NB_PIECES_RANGE, poids_ref]
    type_bien       : "APT" | "MAI" | "ENSEMBLE"
    anciennete      : "NEUF" | "ANCIEN" | "ENSEMBLE"

    Returns
    -------
    pd.DataFrame avec Ville, Periode, prix_mm_3m, prix_mm_12m, surface_*, VF_*,
    nb_observations_*, nb_univers_*, TYPE_BIEN, ANCIENNETE — ou None si vide.
    """
    seg_label = f"{label}_{type_bien}_{anciennete}"

    # --- Filtre segment ---
    uc = univers_complet.copy()
    if type_bien != "ENSEMBLE":
        uc = uc[uc["TYPE_BIEN"] == type_bien]
    if anciennete != "ENSEMBLE":
        uc = uc[uc["BIEN_NEUF"] == anciennete]
    if uc.empty:
        return None

    # --- Application des poids ---
    if structure is not None:
        struct_seg = structure.copy()
        if "Ville" in struct_seg.columns:
            struct_seg["Ville"] = struct_seg["Ville"].astype(str).str.strip().str.upper()
        if type_bien != "ENSEMBLE":
            struct_seg = struct_seg[struct_seg["TYPE_BIEN"] == type_bien]
        if anciennete != "ENSEMBLE":
            struct_seg = struct_seg[struct_seg["BIEN_NEUF"] == anciennete]

        uc = uc.merge(
            struct_seg[TYPOKEYS + ["poids_ref"]],
            on=TYPOKEYS, how="left"
        )
        uc = uc.rename(columns={"poids_ref": "poids_relatif"})
        uc = uc.dropna(subset=["poids_relatif"])
    else:
        # Poids internes
        poids = (
            uc.groupby(TYPOKEYS, as_index=False)["nb_transac"]
            .sum().rename(columns={"nb_transac": "poids_total"})
        )
        poids["poids_relatif"] = poids.groupby("Ville")["poids_total"].transform(
            lambda x: x / x.sum()
        )
        uc = uc.merge(poids, on=TYPOKEYS, how="left")

    if uc.empty:
        return None

    # Renormaliser les poids par Ville (important quand on a filtré des univers)
    uc["poids_relatif"] = uc.groupby(["Ville", "Periode"])["poids_relatif"].transform(
        lambda x: x / x.sum() if x.sum() > 0 else x
    )

    # --- Indicatrices ---
    uc = uc.sort_values(TYPOKEYS + ["Periode"])
    uc["I_3m"]  = uc.groupby(TYPOKEYS)["nb_transac"].transform(
        lambda s: (s.rolling(3, min_periods=3).sum() > 0).astype(int)
    )
    uc["I_12m"] = uc.groupby(TYPOKEYS)["nb_transac"].transform(
        lambda s: (s.rolling(12, min_periods=12).sum() > 0).astype(int)
    )

    # --- calc_mm ---
    def calc_mm(g, window, col_indic, variable_col):
        result = []
        g = g.sort_values("Periode")
        periodes = g["Periode"].unique()
        for i, periode in enumerate(periodes):
            start   = max(0, i - window + 1)
            fenetre = g[g["Periode"].isin(periodes[start:i+1])]
            actifs  = fenetre[(fenetre[variable_col].notna()) & (fenetre[col_indic] == 1)]
            if actifs.empty:
                result.append({"Periode": periode, "val": np.nan, "nb_obs": 0, "nb_univ": 0})
                continue
            nb_obs  = int(actifs["nb_transac"].sum())
            nb_univ = actifs[["BIEN_NEUF", "TYPE_BIEN", "NB_PIECES_RANGE"]].drop_duplicates().shape[0]
            pw      = actifs["poids_relatif"].sum()
            val     = np.average(actifs[variable_col], weights=actifs["poids_relatif"]) if pw > 0 else np.nan
            result.append({"Periode": periode, "val": val, "nb_obs": nb_obs, "nb_univ": nb_univ})
        return pd.DataFrame(result)

    res_final = []
    for ville, df_ville in uc.groupby("Ville"):
        mm12 = calc_mm(df_ville, 12, "I_12m", "prix_moyen").rename(columns={"val": "prix_mm_12m", "nb_obs": "nb_observations_12m", "nb_univ": "nb_univers_12m"})
        mm3  = calc_mm(df_ville, 3,  "I_3m",  "prix_moyen").rename(columns={"val": "prix_mm_3m",  "nb_obs": "nb_observations_3m",  "nb_univ": "nb_univers_3m"})
        s12  = calc_mm(df_ville, 12, "I_12m", "surface_moyen")[["Periode", "val"]].rename(columns={"val": "surface_mm_12m"})
        s3   = calc_mm(df_ville, 3,  "I_3m",  "surface_moyen")[["Periode", "val"]].rename(columns={"val": "surface_mm_3m"})
        v12  = calc_mm(df_ville, 12, "I_12m", "valeur_fonc_moyen")[["Periode", "val"]].rename(columns={"val": "VF_mm_12m"})
        v3   = calc_mm(df_ville, 3,  "I_3m",  "valeur_fonc_moyen")[["Periode", "val"]].rename(columns={"val": "VF_mm_3m"})

        merged = mm12
        for df_m in [mm3, s12, s3, v12, v3]:
            merged = merged.merge(df_m, on="Periode", how="outer")
        merged["Ville"] = ville
        res_final.append(merged)

    if not res_final:
        return None

    result = pd.concat(res_final, ignore_index=True)
    result["TYPE_BIEN"]  = type_bien
    result["ANCIENNETE"] = anciennete
    print(f"  ✓ {type_bien} × {anciennete} : {len(result)} lignes")
    return result


# ===========================================================================
# FONCTIONS UTILITAIRES : structure de marché
# ===========================================================================

def extract_structure(df: pd.DataFrame, maille_col: str, maille_name: str, output_dir: str) -> pd.DataFrame:
    """Calcule et sauvegarde la structure de marché (poids par univers élémentaire)."""
    print(f"\n   Extraction structure {maille_name}...")
    dims = [maille_col, "BIEN_NEUF", "TYPE_BIEN", "NB_PIECES_RANGE"]
    structure = df.groupby(dims, dropna=False).size().reset_index(name="volume_ref")
    structure["TYPE_BIEN"] = structure["TYPE_BIEN"].astype(str).str.upper().str.strip()
    structure["PB"] = structure["NB_PIECES_RANGE"].astype(str).str.strip().str[:3].str.upper()
    structure = structure[structure["TYPE_BIEN"] == structure["PB"]].drop(columns=["PB"])
    structure["poids_ref"] = structure.groupby(maille_col)["volume_ref"].transform(lambda x: x / x.sum())

    path = os.path.join(output_dir, f"structure_poids_{maille_name}.csv")
    structure.to_csv(path, index=False, encoding="utf-8-sig")
    print(f"      -> structure_poids_{maille_name}.csv ({len(structure)} univers, {structure[maille_col].nunique()} {maille_name})")
    return structure


def _process_maille(
    df_data: pd.DataFrame,
    df_struct_src: pd.DataFrame,
    maille_col: str,
    maille_name: str,
    output_dir: str,
    label: str,
    df_arr=None
) -> pd.DataFrame | None:
    """
    Calcule toutes les combinaisons TYPE_BIEN × ANCIENNETE pour une maille.
    build_univers_complet() est appelé UNE SEULE FOIS, le résultat est filtré 9 fois.
    """
    print(f"\n--- Traitement de la maille : {maille_name} ---")
    start = datetime.now()

    # Préparer df_work (renommer maille_col → Ville)
    df_work = df_data.copy()
    if maille_col != "Ville":
        if "Ville" in df_work.columns:
            df_work = df_work.drop(columns=["Ville"])
        df_work = df_work.rename(columns={maille_col: "Ville"})
    df_work["Ville"] = df_work["Ville"].astype(str).str.strip().str.upper()
    df_work = df_work.dropna(subset=["Ville", "TYPE_BIEN", "NB_PIECES_RANGE"])

    # Préparer structure (renommer maille_col → Ville + upper)
    structure_base = None
    if df_struct_src is not None:
        structure_base = df_struct_src.copy()
        if maille_col in structure_base.columns and maille_col != "Ville":
            structure_base = structure_base.rename(columns={maille_col: "Ville"})
        if "Ville" in structure_base.columns:
            structure_base["Ville"] = structure_base["Ville"].astype(str).str.strip().str.upper()

    # ---------------------------------------------------------------
    # ÉTAPE LOURDE : une seule fois pour cette maille
    # ---------------------------------------------------------------
    print(f"  → Construction univers_complet (1× pour toute la maille)...")
    t0 = datetime.now()
    univers_complet = build_univers_complet(df_work)
    print(f"     terminé en {datetime.now() - t0} — {len(univers_complet)} lignes")

    # Pour CITY, gérer les arrondissements Paris/Lyon/Marseille
    # (df_arr est passé uniquement pour CITY)
    # TODO: intégrer moy_pond_cities pour ENSEMBLE si df_arr fourni

    # ---------------------------------------------------------------
    # BOUCLE LÉGÈRE : 9 combinaisons TYPE_BIEN × ANCIENNETE
    # ---------------------------------------------------------------
    all_segments = []
    for tb in TYPES_BIEN + ["ENSEMBLE"]:
        for anc in ANCIENNETES + ["ENSEMBLE"]:
            seg = _calc_mm_on_cache(univers_complet, label, structure_base, tb, anc)
            if seg is not None:
                seg["VAL_MAILLE_GEO"] = seg["Ville"]
                seg["TYPE_MAILLE"]    = maille_name
                seg = seg.drop(columns=["Ville"])
                all_segments.append(seg)

    if not all_segments:
        print(f"  ✗ Aucune donnée pour la maille {maille_name}")
        return None

    final = pd.concat(all_segments, ignore_index=True)

    # Taux d'inflation
    gc = ["VAL_MAILLE_GEO", "TYPE_MAILLE", "TYPE_BIEN", "ANCIENNETE"]
    final = final.sort_values(gc + ["Periode"])
    final["TAUX_INFL_12M"] = final.groupby(gc)["prix_mm_3m"].pct_change(periods=12, fill_method=None)
    final["TAUX_INFL_3M"]  = final.groupby(gc)["prix_mm_3m"].pct_change(periods=3,  fill_method=None)

    print(f"Traitement {maille_name} terminé en {datetime.now() - start} — {len(final)} lignes")
    return final


# ===========================================================================
# POINT D'ENTRÉE : run(cfg)
# ===========================================================================

def run(cfg: dict):
    """
    Lance le calcul des prix pour toutes les mailles et tous les segments.

    Parameters
    ----------
    cfg : dict retourné par config.get_config()
    """
    start_global = datetime.now()
    output_dir   = cfg["output_dir"]
    label        = cfg["label"]
    os.makedirs(output_dir, exist_ok=True)

    # ------------------------------------------------------------------
    # Chargement des bases
    # ------------------------------------------------------------------
    print("\nChargement des données...")
    base_prix = load_and_preprocess_data(specific_path=cfg["path_base"])
    if "CITY" in base_prix.columns:
        base_prix = base_prix.rename(columns={"CITY": "Ville"})
    if cfg.get("source_filter"):
        base_prix = base_prix[base_prix["SOURCE"] == cfg["source_filter"]]
    print(f"  Base prix : {len(base_prix)} lignes ({cfg['description']})")

    # Base structurelle (peut être différente de la base prix)
    if cfg["path_structure"] != cfg["path_base"]:
        base_struct = load_and_preprocess_data(specific_path=cfg["path_structure"])
        if "CITY" in base_struct.columns:
            base_struct = base_struct.rename(columns={"CITY": "Ville"})
    else:
        base_struct = base_prix.copy()
    print(f"  Base structure : {len(base_struct)} lignes")

    print("\n" + "="*80)
    print("EXTRACTION DES STRUCTURES DE MARCHÉ")
    print("="*80)

    all_results = []

    # ------------------------------------------------------------------
    # PROVINCE
    # ------------------------------------------------------------------
    df_prov = base_prix.copy()
    mask_prov = ~df_prov["DEPT"].isin(params.CONFIG["idf_depts"])
    df_prov.loc[mask_prov, "Ville"] = "PROVINCE"
    df_prov = df_prov[df_prov["Ville"] == "PROVINCE"]

    df_prov_struct = base_struct.copy()
    mask_s = ~df_prov_struct["DEPT"].isin(params.CONFIG["idf_depts"])
    df_prov_struct.loc[mask_s, "Ville"] = "PROVINCE"
    df_prov_struct = df_prov_struct[df_prov_struct["Ville"] == "PROVINCE"]

    struct_province = extract_structure(df_prov_struct, "Ville", "PROVINCE", output_dir)
    res = _process_maille(df_prov, struct_province, "Ville", "PROVINCE", output_dir, label)
    if res is not None:
        all_results.append(res)

    # ------------------------------------------------------------------
    # CITY
    # ------------------------------------------------------------------
    df_villes = apply_nice_correction(base_prix.copy())
    df_villes = df_villes[df_villes["Ville"].isin(params.CONFIG["top_cities"])]

    print("\n   Extraction structure CITY (avec arrondissements)...")
    struct_villes, struct_arr = get_structure_reference_city(base_struct)
    struct_villes.to_csv(os.path.join(output_dir, "structure_poids_CITY.csv"), index=False, encoding="utf-8-sig")
    struct_arr.to_csv(os.path.join(output_dir, "structure_poids_arrondissements.csv"), index=False, encoding="utf-8-sig")

    res = _process_maille(df_villes, struct_villes, "Ville", "CITY", output_dir, label, df_arr=struct_arr)
    if res is not None:
        all_results.append(res)

    # ------------------------------------------------------------------
    # DEPT
    # ------------------------------------------------------------------
    struct_dept = extract_structure(base_struct, "DEPT", "DEPT", output_dir)
    res = _process_maille(base_prix, struct_dept, "DEPT", "DEPT", output_dir, label)
    if res is not None:
        all_results.append(res)

    # ------------------------------------------------------------------
    # REGION
    # ------------------------------------------------------------------
    struct_region = extract_structure(base_struct, "REGION", "REGION", output_dir)
    res = _process_maille(base_prix, struct_region, "REGION", "REGION", output_dir, label)
    if res is not None:
        all_results.append(res)

    # ------------------------------------------------------------------
    # NATIONAL
    # ------------------------------------------------------------------
    df_nat = base_prix.copy()
    df_nat["PAYS"] = "FRANCE"
    df_nat_struct = base_struct.copy()
    df_nat_struct["PAYS"] = "FRANCE"
    struct_nat = extract_structure(df_nat_struct, "PAYS", "NATIONAL", output_dir)
    res = _process_maille(df_nat, struct_nat, "PAYS", "NATIONAL", output_dir, label)
    if res is not None:
        all_results.append(res)

    # ------------------------------------------------------------------
    # Consolidation et sauvegarde
    # ------------------------------------------------------------------
    print("\n" + "="*80)
    print("CONSOLIDATION")
    print("="*80)

    if not all_results:
        print("ERREUR : aucun résultat.")
        return

    df_all = pd.concat(all_results, ignore_index=True)

    col_order = [
        "VAL_MAILLE_GEO", "TYPE_MAILLE", "TYPE_BIEN", "ANCIENNETE", "Periode",
        "prix_mm_3m", "prix_mm_12m", "surface_mm_3m", "surface_mm_12m",
        "VF_mm_3m", "VF_mm_12m",
        "nb_observations_3m", "nb_observations_12m",
        "nb_univers_3m", "nb_univers_12m",
        "TAUX_INFL_3M", "TAUX_INFL_12M"
    ]
    col_order = [c for c in col_order if c in df_all.columns]
    df_all = df_all[col_order].sort_values(
        ["TYPE_MAILLE", "VAL_MAILLE_GEO", "TYPE_BIEN", "ANCIENNETE", "Periode"]
    )

    path_all = os.path.join(output_dir, "prix_m2_univ_elem_ALL.csv")
    df_all.to_csv(path_all, index=False, encoding="utf-8-sig")
    print(f"\n-> prix_m2_univ_elem_ALL.csv : {len(df_all)} lignes")

    key_cols = ["VAL_MAILLE_GEO", "TYPE_MAILLE", "TYPE_BIEN", "ANCIENNETE"]
    df_maj = df_all.loc[df_all.groupby(key_cols)["Periode"].idxmax()].reset_index(drop=True)
    path_maj = os.path.join(output_dir, "prix_m2_univ_elem_MAJ_ALL.csv")
    df_maj.to_csv(path_maj, index=False, encoding="utf-8-sig")
    print(f"-> prix_m2_univ_elem_MAJ_ALL.csv : {len(df_maj)} lignes")

    print(f"\nCalc prix terminé en {datetime.now() - start_global}")
