"""
pipeline/cartes.py — Génération des 2 cartes PNG des prix au m².

Paramétrable via cfg['segment_carte'] :
    TYPE_BIEN  : "APT" | "MAI" | "ENSEMBLE"
    ANCIENNETE : "NEUF" | "ANCIEN" | "ENSEMBLE"

Cartes produites (dans output_dir) :
    carte_couts_operations_{TYPE_BIEN}_{ANCIENNETE}.png   — Prix, Surface, Coût
    carte_prix_m2_evolution_{TYPE_BIEN}_{ANCIENNETE}.png  — Prix + Évolutions 3M/12M
"""
import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import geopandas as gpd
from shapely.geometry import Point
from matplotlib.offsetbox import AnnotationBbox, TextArea, HPacker

import param_generaux as params

# ---------------------------------------------------------------------------
# Constantes graphiques
# ---------------------------------------------------------------------------
CL_TURQUOISE   = "#A8DADC"
CL_BLACK       = "#1D3557"
CL_LIGHT_GREY  = "#F5F5DC"
CL_BLUE_3M     = "#000000"
CL_RED_12M     = "#CB4735"
TARGET_CRS     = "EPSG:2154"
DEFAULT_FONT_SIZE = 20
TAUX_FONT_SIZE    = 11
TITRE_FONT_WEIGHT = "heavy"

X_OFFSET_DEFAULT = 3000
Y_OFFSET_DEFAULT = 3000
CUSTOM_LABEL_OFFSETS = {
    "MONTPELLIER": {"x": 5000,   "y": 90000},
    "MARSEILLE":   {"x": 5000,   "y": -15000},
    "NICE":        {"x": 30000,  "y": 3000},
    "GRENOBLE":    {"x": 5000,   "y": 10000},
    "ST ETIENNE":  {"x": -30000, "y": 0},
    "SAINT-ETIENNE": {"x": -30000, "y": 0},
    "LE HAVRE":    {"x": 10000,  "y": 0},
    "BORDEAUX":    {"x": 5000,   "y": 20000},
    "NANTES":      {"x": 5000,   "y": 20000},
    "RENNES":      {"x": 5000,   "y": 40000},
    "LILLE":       {"x": 0,      "y": -10000},
    "STRASBOURG":  {"x": -5000,  "y": 0},
    "PARIS":       {"x": 5000,   "y": 3000},
    "LYON":        {"x": 0,      "y": 90000},
    "TOULOUSE":    {"x": -5000,  "y": 20000},
    "TOURS":       {"x": 5000,   "y": -3000},
    "BREST":       {"x": -35000, "y": 0},
    "REIMS":       {"x": 20000,  "y": 30000},
}
_MOIS_FR = {1:"JANVIER",2:"FEVRIER",3:"MARS",4:"AVRIL",5:"MAI",6:"JUIN",
            7:"JUILLET",8:"AOUT",9:"SEPTEMBRE",10:"OCTOBRE",11:"NOVEMBRE",12:"DECEMBRE"}


def _init_matplotlib():
    try:
        plt.rcParams["font.family"]     = "sans-serif"
        plt.rcParams["font.sans-serif"] = ["Century Gothic", "Arial", "Verdana"]
    except Exception:
        pass
    plt.rcParams["font.weight"] = "medium"


def _load_france_geometry(path_geojson: str):
    france_gdf = gpd.read_file(path_geojson)
    dissolved  = france_gdf.dissolve(by=None).to_crs(TARGET_CRS)
    geom       = dissolved.geometry.iloc[0]
    geoms      = list(geom.geoms) if geom.geom_type == "MultiPolygon" else [geom]
    geoms.sort(key=lambda x: x.area, reverse=True)
    return geoms[0]


def _draw_france_base(ax, outline_geom):
    """Dessine le fond de carte France."""
    x, y = outline_geom.exterior.xy
    ax.fill(x, y, color=CL_LIGHT_GREY, zorder=1)
    ax.plot(x, y, color=CL_BLACK, linewidth=1.0, zorder=2)
    xmin, ymin, xmax, ymax = outline_geom.bounds
    ax.set_xlim(xmin - 5000, xmax + 5000)
    ax.set_ylim(ymin - 5000, ymax + 5000)
    ax.axis("off")


def _load_prix_csv(cfg: dict, tb: str, anc: str) -> pd.DataFrame:
    """Charge le CSV MAJ et filtre sur le segment + maille CITY."""
    path = os.path.join(cfg["output_dir"], "prix_m2_univ_elem_MAJ_ALL.csv")
    if not os.path.exists(path):
        print(f"  ⚠ Fichier introuvable : {path}  → relancer l'étape prix d'abord.")
        return pd.DataFrame()
    df = pd.read_csv(path, parse_dates=["Periode"])
    df = df[
        (df["TYPE_MAILLE"] == "CITY") &
        (df["TYPE_BIEN"]   == tb) &
        (df["ANCIENNETE"]  == anc)
    ].copy()
    df["VAL_MAILLE_GEO"] = df["VAL_MAILLE_GEO"].astype(str).str.strip().str.upper()
    df["VAL_MAILLE_GEO"] = df["VAL_MAILLE_GEO"].replace({
        "HAVRE":         "LE HAVRE",
        "SAINT-ETIENNE": "ST ETIENNE",
        "SAINT ETIENNE": "ST ETIENNE",
    })
    return df


# ===========================================================================
# CARTE 1 : Coûts des opérations (prix m², surface, valeur foncière)
# ===========================================================================

def carte_couts(cfg: dict, df_prix: pd.DataFrame, df_gps: pd.DataFrame,
                outline_geom, tb: str, anc: str):
    if df_prix.empty:
        print("  ⚠ Aucune donnée pour la Carte 1.")
        return

    df_map = df_gps.merge(df_prix, left_on="label", right_on="VAL_MAILLE_GEO", how="inner")
    df_map = df_map.dropna(subset=["latitude", "longitude", "prix_mm_3m"])
    df_map = df_map.drop_duplicates(subset="label", keep="first")
    if df_map.empty:
        print("  ⚠ Aucune jointure GPS pour la Carte 1.")
        return

    geometry = [Point(xy) for xy in zip(df_map["longitude"], df_map["latitude"])]
    gdf = gpd.GeoDataFrame(df_map, geometry=geometry, crs="EPSG:4326").to_crs(TARGET_CRS)

    fig, ax = plt.subplots(1, 1, figsize=(14, 14), dpi=300)
    fig.set_facecolor(CL_TURQUOISE)
    _draw_france_base(ax, outline_geom)

    halo  = [pe.withStroke(linewidth=2.5, foreground="white")]
    LS    = 15000  # interligne

    for _, row in gdf.iterrows():
        cx, cy    = row.geometry.x, row.geometry.y
        city_lbl  = str(row["label"]).upper()
        off       = CUSTOM_LABEL_OFFSETS.get(city_lbl, {"x": X_OFFSET_DEFAULT, "y": Y_OFFSET_DEFAULT})
        ax_x, ax_y = cx + off["x"], cy + off["y"]
        ha        = "right" if off["x"] < 0 else "left"

        prix_str = f"{int(row['prix_mm_3m']):,} EUR/m2".replace(",", " ")         if pd.notna(row.get("prix_mm_3m"))   else "N/A"
        surf_str = f"{int(row['surface_mm_3m']):,} m2".replace(",", " ")          if pd.notna(row.get("surface_mm_3m")) else "N/A"
        vf_val   = row.get("VF_mm_3m")
        vf_str   = f"{int(vf_val):,} EUR".replace(",", " ")                       if pd.notna(vf_val)                  else "N/A"

        ax.text(ax_x, ax_y,           city_lbl, fontsize=DEFAULT_FONT_SIZE,      ha=ha, va="top", color=CL_BLACK,   weight="normal", zorder=4, path_effects=halo)
        ax.text(ax_x, ax_y - 1.5*LS, prix_str, fontsize=0.85*DEFAULT_FONT_SIZE, ha=ha, va="top", color=CL_BLACK,   weight="bold",   zorder=4, path_effects=halo)
        ax.text(ax_x, ax_y - 3.0*LS, surf_str, fontsize=0.75*DEFAULT_FONT_SIZE, ha=ha, va="top", color="#4A4A8A",  weight="normal", zorder=4, path_effects=halo)
        ax.text(ax_x, ax_y - 4.5*LS, vf_str,   fontsize=0.75*DEFAULT_FONT_SIZE, ha=ha, va="top", color="#8B0000",  weight="normal", zorder=4, path_effects=halo)
        ax.plot(cx, cy, marker="o", color=CL_BLACK, markersize=5, zorder=4, markeredgecolor="white", markeredgewidth=0.5)

    titre_tb  = {"APT": "APPARTEMENTS", "MAI": "MAISONS", "ENSEMBLE": "LOGEMENTS"}
    titre_anc = {"ANCIEN": "ANCIENS", "NEUF": "NEUFS", "ENSEMBLE": ""}
    ax.set_title(f"COÛTS DES OPÉRATIONS – {titre_tb.get(tb, tb)} {titre_anc.get(anc, anc)}",
                 fontsize=28, loc="center", pad=20, color=CL_BLACK, weight=TITRE_FONT_WEIGHT,
                 bbox=dict(facecolor="white", edgecolor="black", boxstyle="round,pad=0.4"))
    fig.text(0.04, 0.07, "LÉGENDE\nPrix pondéré au m²\nSurface pondérée\nCoût pondéré de l'opération",
             ha="left", va="bottom", fontsize=16,
             bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="black", alpha=0.8))

    derniere = df_prix["Periode"].max()
    if pd.notna(derniere):
        date_str = f"{_MOIS_FR[derniere.month]} {derniere.year}"
    else:
        date_str = "DATE INCONNUE"
    fig.text(0.04, 0.02, f"CREDIT LOGEMENT - {date_str}", ha="left", va="bottom", fontsize=12)

    out = os.path.join(cfg["output_dir"], f"carte_couts_operations_{tb}_{anc}.png")
    plt.savefig(out, dpi=300, bbox_inches=None, facecolor=fig.get_facecolor())
    plt.close()
    print(f"   -> Sauvegardé : {out}")


# ===========================================================================
# CARTE 2 : Prix au m² + Évolutions 3M / 12M
# ===========================================================================

def carte_prix_evolution(cfg: dict, df_prix: pd.DataFrame, df_gps: pd.DataFrame,
                         outline_geom, tb: str, anc: str):
    if df_prix.empty:
        print("  ⚠ Aucune donnée pour la Carte 2.")
        return

    df_map = df_gps.merge(df_prix, left_on="label", right_on="VAL_MAILLE_GEO", how="inner")
    cols_needed = ["label", "latitude", "longitude", "prix_mm_3m", "TAUX_INFL_3M", "TAUX_INFL_12M"]
    for c in ["TAUX_INFL_3M", "TAUX_INFL_12M"]:
        if c not in df_map.columns:
            df_map[c] = np.nan
    df_map = df_map[cols_needed].dropna(subset=["latitude", "longitude"]).drop_duplicates(subset="label", keep="first")
    if df_map.empty:
        print("  ⚠ Aucune jointure GPS pour la Carte 2.")
        return

    geometry = [Point(xy) for xy in zip(df_map["longitude"], df_map["latitude"])]
    gdf = gpd.GeoDataFrame(df_map, geometry=geometry, crs="EPSG:4326").to_crs(TARGET_CRS)

    fig, ax = plt.subplots(1, 1, figsize=(14, 14), dpi=300)
    fig.set_facecolor(CL_TURQUOISE)
    _draw_france_base(ax, outline_geom)

    halo = [pe.withStroke(linewidth=2.5, foreground="white")]
    LINE_SPACING = 15000

    for _, row in gdf.iterrows():
        cx, cy   = row.geometry.x, row.geometry.y
        city_lbl = str(row["label"]).upper()
        off      = CUSTOM_LABEL_OFFSETS.get(city_lbl, {"x": X_OFFSET_DEFAULT, "y": Y_OFFSET_DEFAULT})
        anc_x    = cx + off["x"]
        anc_y    = cy + off["y"]
        ha       = "right" if off["x"] < 0 else "left"

        prix_val = row["prix_mm_3m"]
        prix_str = f"{round(prix_val):,} €".replace(",", " ") if pd.notna(prix_val) else "N/A"
        ti_3m    = row["TAUX_INFL_3M"]
        ti_12m   = row["TAUX_INFL_12M"]

        ax.text(anc_x, anc_y,                  city_lbl, fontsize=DEFAULT_FONT_SIZE,      ha=ha, va="top", color=CL_BLACK, weight="normal", zorder=4, path_effects=halo)
        ax.text(anc_x, anc_y - 1.5*LINE_SPACING, prix_str, fontsize=0.9*DEFAULT_FONT_SIZE, ha=ha, va="top", color=CL_BLACK, weight="bold",   zorder=4, path_effects=halo)

        ti_3m_y  = anc_y - 2.5*LINE_SPACING
        ti_12m_y = ti_3m_y - LINE_SPACING
        text_3m  = f"{ti_3m:+.1%}".replace(".", ",") if pd.notna(ti_3m)  else "N/A"
        text_12m = f"{ti_12m:+.1%}".replace(".", ",")if pd.notna(ti_12m) else "N/A"

        ta_3m  = TextArea(text_3m,  textprops=dict(fontsize=TAUX_FONT_SIZE, color=CL_BLUE_3M, weight="normal"))
        ta_12m = TextArea(text_12m, textprops=dict(fontsize=TAUX_FONT_SIZE, color=CL_RED_12M, weight="normal"))
        hpack  = HPacker(children=[ta_3m, ta_12m], align="center", pad=0, sep=8)
        box_x_align = 1.0 if ha == "right" else 0.0
        ab = AnnotationBbox(hpack, (anc_x, ti_12m_y), xybox=(0, 0), xycoords="data",
                            boxcoords="offset points", frameon=False,
                            box_alignment=(box_x_align, 0.5))
        ax.add_artist(ab)
        ax.plot(cx, cy, marker="o", color=CL_BLACK, markersize=5, zorder=4,
                markeredgecolor="white", markeredgewidth=0.5)

    titre_tb  = {"APT": "APPARTEMENTS", "MAI": "MAISONS", "ENSEMBLE": "LOGEMENTS"}
    titre_anc = {"ANCIEN": "ANCIENS", "NEUF": "NEUFS", "ENSEMBLE": ""}
    nb_villes = len(params.CONFIG.get("top_cities", []))
    ax.set_title(f"LES PRIX DES {titre_tb.get(tb, tb)} {titre_anc.get(anc, anc)} DANS LES {nb_villes} PLUS GRANDES VILLES",
                 fontsize=26, loc="center", pad=20, color=CL_BLACK, weight=TITRE_FONT_WEIGHT,
                 bbox=dict(facecolor="white", edgecolor="black", boxstyle="round,pad=0.4"))
    fig.text(0.04, 0.05, "LÉGENDE\nPrix/m² moyen sur 3 mois glissants\nNoir : Évolution 3 mois\nRouge : Évolution 12 mois",
             ha="left", va="bottom", fontsize=16,
             bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="black", alpha=0.8))

    derniere = df_prix["Periode"].max()
    date_str = f"{_MOIS_FR[derniere.month]} {derniere.year}" if pd.notna(derniere) else "DATE INCONNUE"
    fig.text(0.04, 0.02, f"CREDIT LOGEMENT - {date_str}", ha="left", va="bottom", fontsize=12)

    out = os.path.join(cfg["output_dir"], f"carte_prix_m2_evolution_{tb}_{anc}.png")
    plt.savefig(out, dpi=300, bbox_inches=None, facecolor=fig.get_facecolor())
    plt.close()
    print(f"   -> Sauvegardé : {out}")


# ===========================================================================
# POINT D'ENTRÉE : run(cfg)
# ===========================================================================

def run(cfg: dict):
    """
    Génère les 2 cartes PNG pour le segment défini dans cfg['segment_carte'].

    Parameters
    ----------
    cfg : dict retourné par config.get_config()
    """
    tb  = cfg["segment_carte"]["TYPE_BIEN"]
    anc = cfg["segment_carte"]["ANCIENNETE"]
    print(f"\nGénération des cartes — segment : {tb} × {anc}")

    _init_matplotlib()

    # Chargement données GPS
    df_gps = pd.read_csv(cfg["path_gps"], sep=";")
    df_gps["label"] = df_gps["label"].astype(str).str.upper().str.strip()

    # Fond de carte
    outline_geom = _load_france_geometry(cfg["path_geojson"])

    # Données de prix (filtrées sur segment + CITY)
    df_prix = _load_prix_csv(cfg, tb, anc)

    # Carte 1 : coûts d'opérations
    print("\n--- Carte 1 : Coûts des opérations ---")
    carte_couts(cfg, df_prix, df_gps, outline_geom, tb, anc)

    # Carte 2 : prix + évolutions
    print("\n--- Carte 2 : Prix au m² + Évolutions ---")
    carte_prix_evolution(cfg, df_prix, df_gps, outline_geom, tb, anc)
