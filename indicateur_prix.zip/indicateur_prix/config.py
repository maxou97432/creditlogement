"""
config.py — Paramètres de run centralisés pour la pipeline indicateur_prix.

C'est ici qu'on choisit :
- La variante de base (v1_complet = DVF+CL, v2_restreint = CL uniquement)
- Le segment à afficher sur les cartes (TYPE_BIEN × ANCIENNETE)
- Les chemins de données (surchargés par main.py via argparse si besoin)

Ce fichier est importé par tous les modules de la pipeline.
"""
import os

# ---------------------------------------------------------------------------
# Répertoire courant du projet
# ---------------------------------------------------------------------------
PROJECT_DIR = os.path.dirname(__file__)

# ---------------------------------------------------------------------------
# Variante de base par défaut
# Peut être surchargée via main.py --variante
# ---------------------------------------------------------------------------
VARIANTE_DEFAULT = "v2_restreint"   # "v1_complet" | "v2_restreint"

# ---------------------------------------------------------------------------
# Définition des variantes
# Chaque variante définit :
#   path_base       : parquet sur lequel on calcule les PRIX
#   source_filter   : filtre SOURCE appliqué à la base ("CL" | None)
#   label           : label court utilisé dans les colonnes de résultats
#   output_subdir   : sous-dossier de sortie dans resultats/
# ---------------------------------------------------------------------------
VARIANTES = {
    "v1_complet": {
        "path_base":      r"Z:\uflumth\gits\univers_elementaire\TI\stats_base_complete_filtree\base_complete_filtree.parquet",
        "source_filter":  None,           # DVF + CL, aucun filtre
        "label":          "V1",
        "output_subdir":  "v1_complet",
        "description":    "Base complète DVF + CL"
    },
    "v2_restreint": {
        "path_base":      r"Z:\uflumth\gits\univers_elementaire\TI - V2\resultats\base_restreinte.parquet",
        "source_filter":  "CL",           # Crédit Logement uniquement
        "label":          "V2",
        "output_subdir":  "v2_restreint",
        "description":    "Base restreinte CL uniquement"
    },
}

# ---------------------------------------------------------------------------
# Base structurelle (poids) — toujours DVF+CL pour être représentatif
# ---------------------------------------------------------------------------
PATH_BASE_STRUCTURE = r"Z:\uflumth\gits\univers_elementaire\TI\stats_base_complete_filtree\base_complete_filtree.parquet"

# ---------------------------------------------------------------------------
# Chemin du fichier LPI-IAD (benchmark externe)
# ---------------------------------------------------------------------------
PATH_LPI = r"N:\uflumth\indicateur_marche\LPI-IAD donnees (v2).xlsx"

# ---------------------------------------------------------------------------
# Chemin GPS et GeoJSON pour les cartes
# ---------------------------------------------------------------------------
PATH_GEOJSON  = r"Z:\uflumth\gits\univers_elementaire\TI\metropole-version-simplifiee.geojson"
PATH_GPS      = r"N:\uflujek\commune_france_gps.csv"
PATH_COMMUNES = r"N:\uflujek\Commune_france.xlsx"

# ---------------------------------------------------------------------------
# Segment à afficher sur les cartes
# Peut être surchargé via main.py --type_bien et --anciennete
# ---------------------------------------------------------------------------
SEGMENT_CARTE_DEFAULT = {
    "TYPE_BIEN":  "APT",      # "APT" | "MAI" | "ENSEMBLE"
    "ANCIENNETE": "ANCIEN",   # "NEUF" | "ANCIEN" | "ENSEMBLE"
}

# ---------------------------------------------------------------------------
# Étapes disponibles dans la pipeline (ordre d'exécution)
# ---------------------------------------------------------------------------
ETAPES_DISPONIBLES = ["base", "base_restreinte", "prix", "cartes", "lpi"]

# ---------------------------------------------------------------------------
# Dossier de résultats racine
# ---------------------------------------------------------------------------
RESULTATS_DIR = os.path.join(PROJECT_DIR, "resultats")


def get_config(variante: str = None, segment: dict = None) -> dict:
    """
    Retourne la configuration complète pour un run.

    Parameters
    ----------
    variante : str, optionnel
        "v1_complet" ou "v2_restreint". Par défaut VARIANTE_DEFAULT.
    segment  : dict, optionnel
        {"TYPE_BIEN": ..., "ANCIENNETE": ...}. Par défaut SEGMENT_CARTE_DEFAULT.

    Returns
    -------
    dict avec les clés :
        variante, path_base, source_filter, label, output_dir,
        path_structure, path_lpi, segment_carte, path_geojson, path_gps
    """
    v = variante or VARIANTE_DEFAULT
    if v not in VARIANTES:
        raise ValueError(f"Variante inconnue '{v}'. Choix : {list(VARIANTES)}")

    var_cfg = VARIANTES[v]
    output_dir = os.path.join(RESULTATS_DIR, var_cfg["output_subdir"])
    os.makedirs(output_dir, exist_ok=True)

    return {
        "variante":       v,
        "path_base":      var_cfg["path_base"],
        "source_filter":  var_cfg["source_filter"],
        "label":          var_cfg["label"],
        "output_dir":     output_dir,
        "description":    var_cfg["description"],
        "path_structure": PATH_BASE_STRUCTURE,
        "path_lpi":       PATH_LPI,
        "path_geojson":   PATH_GEOJSON,
        "path_gps":       PATH_GPS,
        "segment_carte":  segment or SEGMENT_CARTE_DEFAULT,
    }
