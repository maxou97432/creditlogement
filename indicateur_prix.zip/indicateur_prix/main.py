"""
main.py — Orchestrateur de la pipeline indicateur prix immobilier.

Usage
-----
# Pipeline complète sur base CL uniquement (défaut)
python main.py

# Pipeline complète sur base DVF+CL
python main.py --variante v1_complet

# Seulement le calcul des prix
python main.py --variante v2_restreint --etapes prix

# Cartes uniquement, segment Maison Ancienne
python main.py --etapes cartes --type_bien MAI --anciennete ANCIEN

# Comparaison LPI uniquement
python main.py --etapes lpi

Étapes disponibles (dans l'ordre) :
    base            → crée base_complete_filtree.parquet (DVF+CL)
    base_restreinte → crée base_restreinte.parquet (CL uniquement)
    prix            → calcule les indices de prix (toutes mailles, tous segments)
    cartes          → génère les 2 cartes PNG (coûts + prix/évolution)
    lpi             → compare avec le baromètre LPI-IAD et génère les graphiques
"""
import sys
import os
import argparse
from datetime import datetime

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

from config import get_config, ETAPES_DISPONIBLES


def parse_args():
    parser = argparse.ArgumentParser(
        description="Pipeline indicateur prix immobilier — Crédit Logement"
    )
    parser.add_argument(
        "--variante",
        default=None,
        choices=["v1_complet", "v2_restreint"],
        help="Variante de base à utiliser (défaut : v2_restreint)"
    )
    parser.add_argument(
        "--etapes",
        default="prix,cartes,lpi",
        help=f"Étapes à exécuter, séparées par des virgules. "
             f"Disponibles : {','.join(ETAPES_DISPONIBLES)} (défaut: prix,cartes,lpi)"
    )
    parser.add_argument(
        "--type_bien",
        default=None,
        choices=["APT", "MAI", "ENSEMBLE"],
        help="Type de bien pour les cartes (défaut : APT)"
    )
    parser.add_argument(
        "--anciennete",
        default=None,
        choices=["NEUF", "ANCIEN", "ENSEMBLE"],
        help="Ancienneté pour les cartes (défaut : ANCIEN)"
    )
    return parser.parse_args()


def main():
    args = parse_args()

    # Segment carte
    segment = {}
    if args.type_bien:
        segment["TYPE_BIEN"] = args.type_bien
    if args.anciennete:
        segment["ANCIENNETE"] = args.anciennete

    # Configuration de run
    cfg = get_config(variante=args.variante, segment=segment or None)

    etapes = [e.strip() for e in args.etapes.split(",")]
    for e in etapes:
        if e not in ETAPES_DISPONIBLES:
            sys.exit(f"Étape inconnue : '{e}'. Disponibles : {ETAPES_DISPONIBLES}")

    print("\n" + "="*80)
    print(f"  PIPELINE INDICATEUR PRIX — {cfg['description'].upper()}")
    print(f"  Variante    : {cfg['variante']}")
    print(f"  Étapes      : {', '.join(etapes)}")
    print(f"  Segment     : {cfg['segment_carte']['TYPE_BIEN']} × {cfg['segment_carte']['ANCIENNETE']}")
    print(f"  Sorties     : {cfg['output_dir']}")
    print("="*80 + "\n")

    start_global = datetime.now()

    # ------------------------------------------------------------------
    # Étape : base (création base_complete_filtree.parquet)
    # ------------------------------------------------------------------
    if "base" in etapes:
        print("\n" + "─"*60)
        print("  ÉTAPE : base_work")
        print("─"*60)
        from pipeline.base_work import run as run_base
        run_base(cfg)

    # ------------------------------------------------------------------
    # Étape : base_restreinte (CL uniquement)
    # ------------------------------------------------------------------
    if "base_restreinte" in etapes:
        print("\n" + "─"*60)
        print("  ÉTAPE : base_restreinte")
        print("─"*60)
        from pipeline.base_restreinte import run as run_restreinte
        run_restreinte(cfg)

    # ------------------------------------------------------------------
    # Étape : prix (calcul indices toutes mailles × tous segments)
    # ------------------------------------------------------------------
    if "prix" in etapes:
        print("\n" + "─"*60)
        print("  ÉTAPE : calc_prix")
        print("─"*60)
        from pipeline.calc_prix import run as run_prix
        run_prix(cfg)

    # ------------------------------------------------------------------
    # Étape : cartes
    # ------------------------------------------------------------------
    if "cartes" in etapes:
        print("\n" + "─"*60)
        print("  ÉTAPE : cartes")
        print("─"*60)
        from pipeline.cartes import run as run_cartes
        run_cartes(cfg)

    # ------------------------------------------------------------------
    # Étape : lpi (comparaison baromètre LPI-IAD)
    # ------------------------------------------------------------------
    if "lpi" in etapes:
        print("\n" + "─"*60)
        print("  ÉTAPE : comparaison_lpi")
        print("─"*60)
        from pipeline.comparaison_lpi import run as run_lpi
        run_lpi(cfg)

    print("\n" + "="*80)
    print(f"  Pipeline terminée en {datetime.now() - start_global}")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()
